﻿namespace AutoMEd
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.AddMarks = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.LabelDateTime = new System.Windows.Forms.Label();
            this.ButtonLoginOldUser = new System.Windows.Forms.Button();
            this.ButtonCreateNewUser = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ButtonBackLogin = new System.Windows.Forms.Button();
            this.SubmitButtonLogin = new System.Windows.Forms.Button();
            this.TextboxLoginCMSID = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.sex = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.TextBoxAddStuCMSID = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.BackButtonAddStu = new System.Windows.Forms.Button();
            this.SubmitButtonAddStu = new System.Windows.Forms.Button();
            this.TextBoxAddStuDepartment = new System.Windows.Forms.TextBox();
            this.TextBoxAddStuCity = new System.Windows.Forms.TextBox();
            this.TextBoxAddStuNoOfCourses = new System.Windows.Forms.TextBox();
            this.TextBoxAddStuSemNo = new System.Windows.Forms.TextBox();
            this.TextBoxAddStuBirthDate = new System.Windows.Forms.TextBox();
            this.TextBoxAddStuLastName = new System.Windows.Forms.TextBox();
            this.TextBoxAddStuFirstName = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.buttonLogOut = new System.Windows.Forms.Button();
            this.labelDT = new System.Windows.Forms.Label();
            this.buttonGrades = new System.Windows.Forms.Button();
            this.buttonAddHabit = new System.Windows.Forms.Button();
            this.buttonAddCareer = new System.Windows.Forms.Button();
            this.buttonAddActivity = new System.Windows.Forms.Button();
            this.buttonAddCourse = new System.Windows.Forms.Button();
            this.label78 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.student_course = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView_StudentCourses = new System.Windows.Forms.DataGridView();
            this.dataGridViewAllCourses = new System.Windows.Forms.DataGridView();
            this.label126 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label124 = new System.Windows.Forms.Label();
            this.AddQuizMarksButton = new System.Windows.Forms.Button();
            this.AddAssiMarksButton = new System.Windows.Forms.Button();
            this.AddExamMarks = new System.Windows.Forms.Button();
            this.CourseIDtextBoxAddcourse = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.InstructorEmailtextBoxAddcourse = new System.Windows.Forms.TextBox();
            this.InstructorNametextBoxAddcourse = new System.Windows.Forms.TextBox();
            this.CourseNametextBoxAddcourse = new System.Windows.Forms.TextBox();
            this.CreditHourstextBoxAddcourse = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.InstructorMobileNotextBoxAddcourse = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.submitButtonAddCourse = new System.Windows.Forms.Button();
            this.MAinMenuButtonAddCourse = new System.Windows.Forms.Button();
            this.label66 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.Deadline = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.textBoxJobTimePeriod = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.textBoxProjectCompany = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.textBoxJobID = new System.Windows.Forms.TextBox();
            this.textBoxProjectTimePeriod = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.textBoxJobCompany = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.textBoxProjectID = new System.Windows.Forms.TextBox();
            this.checkBoxJobApplication = new System.Windows.Forms.CheckBox();
            this.checkBoxProject = new System.Windows.Forms.CheckBox();
            this.checkBoxInternship = new System.Windows.Forms.CheckBox();
            this.textBoxPlannerID = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.MainMenuButtonCareerPlanner = new System.Windows.Forms.Button();
            this.submitButtonCareerPlanner = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBoxInternshipTimePeriod = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxInternshipCompany = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.textBoxInternshipID = new System.Windows.Forms.TextBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.SubmitButtonHabit = new System.Windows.Forms.Button();
            this.dataGridView_StudentHabbit = new System.Windows.Forms.DataGridView();
            this.dataGridViewAllHabts = new System.Windows.Forms.DataGridView();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.MainMenuButtonHabit = new System.Windows.Forms.Button();
            this.textBoxHabitID = new System.Windows.Forms.TextBox();
            this.textBoxHabitName = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.textBoxHabitTimeRemaining = new System.Windows.Forms.TextBox();
            this.textBoxHabitTimeAllocated = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBoxHabitDuration = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dataGridView_StudentActivity = new System.Windows.Forms.DataGridView();
            this.dataGridViewAllActivities = new System.Windows.Forms.DataGridView();
            this.status = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.MainMenuButtonPersonalActivity = new System.Windows.Forms.Button();
            this.SubmitButtonPersonalActivity = new System.Windows.Forms.Button();
            this.textBoxPersonalActivityTime = new System.Windows.Forms.TextBox();
            this.textBoxPersonalActivityID = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBoxActivityName = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.Result = new System.Windows.Forms.DataGridView();
            this.gridallcourses = new System.Windows.Forms.DataGridView();
            this.CalculateGPAbutton = new System.Windows.Forms.Button();
            this.MainMenuButtonGradesGPA = new System.Windows.Forms.Button();
            this.SearchButtonGradesGPA = new System.Windows.Forms.Button();
            this.label70 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.dataGridViewQuizzes = new System.Windows.Forms.DataGridView();
            this.QuizIDtextBoxQuiz = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.StatustextBoxQuiz = new System.Windows.Forms.TextBox();
            this.ObtainedMarkstextBoxQuiz = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.SubmitbuttonAddQuiz = new System.Windows.Forms.Button();
            this.BackbuttonAddQuiz = new System.Windows.Forms.Button();
            this.label79 = new System.Windows.Forms.Label();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.dataGridViewAttempAssignment = new System.Windows.Forms.DataGridView();
            this.AssiIDtextBoxAddAssi = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.StatustextBoxAddAssi = new System.Windows.Forms.TextBox();
            this.ObtainedMarkstextBoxAddAssi = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.SubmitbuttonAddAssi = new System.Windows.Forms.Button();
            this.BackbuttonAddAssi = new System.Windows.Forms.Button();
            this.label89 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.dataGridViewAttemptsExam = new System.Windows.Forms.DataGridView();
            this.ExamIDtextBoxAddExam = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.StatustextBoxAddExam = new System.Windows.Forms.TextBox();
            this.ObtainedMarkstextBoxAddExam = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.SubmitbuttonAddExam = new System.Windows.Forms.Button();
            this.BacktextBoxAddExam = new System.Windows.Forms.Button();
            this.label99 = new System.Windows.Forms.Label();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.Job = new System.Windows.Forms.DataGridView();
            this.Project = new System.Windows.Forms.DataGridView();
            this.Internships = new System.Windows.Forms.DataGridView();
            this.JobtableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.label150 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.ProjecttableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.label141 = new System.Windows.Forms.Label();
            this.label208 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label216 = new System.Windows.Forms.Label();
            this.InternshiptableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.label221 = new System.Windows.Forms.Label();
            this.label222 = new System.Windows.Forms.Label();
            this.label224 = new System.Windows.Forms.Label();
            this.label227 = new System.Windows.Forms.Label();
            this.label229 = new System.Windows.Forms.Label();
            this.SearchbuttonSearchStudentCareer = new System.Windows.Forms.Button();
            this.BackbuttonSearchStudentCareer = new System.Windows.Forms.Button();
            this.AddMarks.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_StudentCourses)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllCourses)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_StudentHabbit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllHabts)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_StudentActivity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllActivities)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Result)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridallcourses)).BeginInit();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewQuizzes)).BeginInit();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAttempAssignment)).BeginInit();
            this.tabPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAttemptsExam)).BeginInit();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Job)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Project)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Internships)).BeginInit();
            this.JobtableLayoutPanel.SuspendLayout();
            this.ProjecttableLayoutPanel.SuspendLayout();
            this.InternshiptableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // AddMarks
            // 
            this.AddMarks.Controls.Add(this.tabPage1);
            this.AddMarks.Controls.Add(this.tabPage2);
            this.AddMarks.Controls.Add(this.tabPage3);
            this.AddMarks.Controls.Add(this.tabPage4);
            this.AddMarks.Controls.Add(this.tabPage5);
            this.AddMarks.Controls.Add(this.tabPage6);
            this.AddMarks.Controls.Add(this.tabPage7);
            this.AddMarks.Controls.Add(this.tabPage8);
            this.AddMarks.Controls.Add(this.tabPage9);
            this.AddMarks.Controls.Add(this.tabPage11);
            this.AddMarks.Controls.Add(this.tabPage12);
            this.AddMarks.Controls.Add(this.tabPage13);
            this.AddMarks.Controls.Add(this.tabPage15);
            this.AddMarks.Location = new System.Drawing.Point(2, 0);
            this.AddMarks.Margin = new System.Windows.Forms.Padding(4);
            this.AddMarks.Name = "AddMarks";
            this.AddMarks.SelectedIndex = 0;
            this.AddMarks.Size = new System.Drawing.Size(1173, 646);
            this.AddMarks.TabIndex = 38;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGray;
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.LabelDateTime);
            this.tabPage1.Controls.Add(this.ButtonLoginOldUser);
            this.tabPage1.Controls.Add(this.ButtonCreateNewUser);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1165, 617);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Start";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Purple;
            this.label15.Location = new System.Drawing.Point(356, 55);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(445, 135);
            this.label15.TabIndex = 38;
            this.label15.Text = "START";
            // 
            // LabelDateTime
            // 
            this.LabelDateTime.AutoSize = true;
            this.LabelDateTime.Font = new System.Drawing.Font("Segoe Script", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelDateTime.ForeColor = System.Drawing.Color.Purple;
            this.LabelDateTime.Location = new System.Drawing.Point(283, 490);
            this.LabelDateTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LabelDateTime.Name = "LabelDateTime";
            this.LabelDateTime.Size = new System.Drawing.Size(253, 67);
            this.LabelDateTime.TabIndex = 37;
            this.LabelDateTime.Text = "Date Time";
            // 
            // ButtonLoginOldUser
            // 
            this.ButtonLoginOldUser.BackColor = System.Drawing.Color.White;
            this.ButtonLoginOldUser.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonLoginOldUser.ForeColor = System.Drawing.Color.Purple;
            this.ButtonLoginOldUser.Location = new System.Drawing.Point(226, 238);
            this.ButtonLoginOldUser.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonLoginOldUser.Name = "ButtonLoginOldUser";
            this.ButtonLoginOldUser.Size = new System.Drawing.Size(315, 201);
            this.ButtonLoginOldUser.TabIndex = 34;
            this.ButtonLoginOldUser.Text = "Login Old User";
            this.ButtonLoginOldUser.UseVisualStyleBackColor = false;
            this.ButtonLoginOldUser.Click += new System.EventHandler(this.ButtonLoginOldUser_Click);
            // 
            // ButtonCreateNewUser
            // 
            this.ButtonCreateNewUser.BackColor = System.Drawing.Color.White;
            this.ButtonCreateNewUser.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCreateNewUser.ForeColor = System.Drawing.Color.Purple;
            this.ButtonCreateNewUser.Location = new System.Drawing.Point(628, 238);
            this.ButtonCreateNewUser.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonCreateNewUser.Name = "ButtonCreateNewUser";
            this.ButtonCreateNewUser.Size = new System.Drawing.Size(315, 201);
            this.ButtonCreateNewUser.TabIndex = 34;
            this.ButtonCreateNewUser.Text = "Create New User";
            this.ButtonCreateNewUser.UseVisualStyleBackColor = false;
            this.ButtonCreateNewUser.Click += new System.EventHandler(this.CreateNewUser_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightBlue;
            this.tabPage2.Controls.Add(this.ButtonBackLogin);
            this.tabPage2.Controls.Add(this.SubmitButtonLogin);
            this.tabPage2.Controls.Add(this.TextboxLoginCMSID);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1165, 617);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Login";
            // 
            // ButtonBackLogin
            // 
            this.ButtonBackLogin.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ButtonBackLogin.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonBackLogin.ForeColor = System.Drawing.SystemColors.WindowText;
            this.ButtonBackLogin.Location = new System.Drawing.Point(104, 540);
            this.ButtonBackLogin.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonBackLogin.Name = "ButtonBackLogin";
            this.ButtonBackLogin.Size = new System.Drawing.Size(133, 44);
            this.ButtonBackLogin.TabIndex = 37;
            this.ButtonBackLogin.Text = "Back";
            this.ButtonBackLogin.UseVisualStyleBackColor = false;
            this.ButtonBackLogin.Click += new System.EventHandler(this.ButtonBackLogin_Click);
            // 
            // SubmitButtonLogin
            // 
            this.SubmitButtonLogin.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.SubmitButtonLogin.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButtonLogin.ForeColor = System.Drawing.SystemColors.WindowText;
            this.SubmitButtonLogin.Location = new System.Drawing.Point(926, 540);
            this.SubmitButtonLogin.Margin = new System.Windows.Forms.Padding(4);
            this.SubmitButtonLogin.Name = "SubmitButtonLogin";
            this.SubmitButtonLogin.Size = new System.Drawing.Size(135, 44);
            this.SubmitButtonLogin.TabIndex = 36;
            this.SubmitButtonLogin.Text = "Submit";
            this.SubmitButtonLogin.UseVisualStyleBackColor = false;
            this.SubmitButtonLogin.Click += new System.EventHandler(this.SubmitButtonLogin_Click);
            // 
            // TextboxLoginCMSID
            // 
            this.TextboxLoginCMSID.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextboxLoginCMSID.Location = new System.Drawing.Point(579, 265);
            this.TextboxLoginCMSID.Margin = new System.Windows.Forms.Padding(4);
            this.TextboxLoginCMSID.Multiline = true;
            this.TextboxLoginCMSID.Name = "TextboxLoginCMSID";
            this.TextboxLoginCMSID.Size = new System.Drawing.Size(228, 36);
            this.TextboxLoginCMSID.TabIndex = 35;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(412, 270);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(109, 31);
            this.label20.TabIndex = 34;
            this.label20.Text = "CMS ID";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label16.Location = new System.Drawing.Point(-220, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label16.Size = new System.Drawing.Size(1383, 114);
            this.label16.TabIndex = 32;
            this.label16.Text = "\r\nLOGIN\r\n";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage3.Controls.Add(this.sex);
            this.tabPage3.Controls.Add(this.label65);
            this.tabPage3.Controls.Add(this.TextBoxAddStuCMSID);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.label77);
            this.tabPage3.Controls.Add(this.label76);
            this.tabPage3.Controls.Add(this.label74);
            this.tabPage3.Controls.Add(this.label73);
            this.tabPage3.Controls.Add(this.label72);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label75);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.BackButtonAddStu);
            this.tabPage3.Controls.Add(this.SubmitButtonAddStu);
            this.tabPage3.Controls.Add(this.TextBoxAddStuDepartment);
            this.tabPage3.Controls.Add(this.TextBoxAddStuCity);
            this.tabPage3.Controls.Add(this.TextBoxAddStuNoOfCourses);
            this.tabPage3.Controls.Add(this.TextBoxAddStuSemNo);
            this.tabPage3.Controls.Add(this.TextBoxAddStuBirthDate);
            this.tabPage3.Controls.Add(this.TextBoxAddStuLastName);
            this.tabPage3.Controls.Add(this.TextBoxAddStuFirstName);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1165, 617);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Add Student";
            // 
            // sex
            // 
            this.sex.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sex.Location = new System.Drawing.Point(562, 290);
            this.sex.Margin = new System.Windows.Forms.Padding(4);
            this.sex.Multiline = true;
            this.sex.Name = "sex";
            this.sex.Size = new System.Drawing.Size(127, 38);
            this.sex.TabIndex = 43;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.Color.Yellow;
            this.label65.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label65.Location = new System.Drawing.Point(-8, 0);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label65.Size = new System.Drawing.Size(1517, 42);
            this.label65.TabIndex = 39;
            this.label65.Text = "                      ADD STUDENT";
            // 
            // TextBoxAddStuCMSID
            // 
            this.TextBoxAddStuCMSID.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxAddStuCMSID.Location = new System.Drawing.Point(562, 87);
            this.TextBoxAddStuCMSID.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxAddStuCMSID.Multiline = true;
            this.TextBoxAddStuCMSID.Name = "TextBoxAddStuCMSID";
            this.TextBoxAddStuCMSID.Size = new System.Drawing.Size(127, 38);
            this.TextBoxAddStuCMSID.TabIndex = 38;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(407, 87);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(109, 31);
            this.label22.TabIndex = 37;
            this.label22.Text = "CMS ID";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(339, 342);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(172, 31);
            this.label77.TabIndex = 36;
            this.label77.Text = "Semester No";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(252, 393);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(255, 31);
            this.label76.TabIndex = 36;
            this.label76.Text = "Number Of Courses";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(455, 441);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(62, 31);
            this.label74.TabIndex = 36;
            this.label74.Text = "City";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(356, 494);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(156, 31);
            this.label73.TabIndex = 36;
            this.label73.Text = "Department";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(455, 290);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(60, 31);
            this.label72.TabIndex = 36;
            this.label72.Text = "Sex";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(377, 245);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(135, 31);
            this.label17.TabIndex = 36;
            this.label17.Text = "Birth Date";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(356, 190);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(145, 31);
            this.label75.TabIndex = 36;
            this.label75.Text = "Last Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(362, 139);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(147, 31);
            this.label21.TabIndex = 36;
            this.label21.Text = "First Name";
            // 
            // BackButtonAddStu
            // 
            this.BackButtonAddStu.BackColor = System.Drawing.Color.Yellow;
            this.BackButtonAddStu.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButtonAddStu.Location = new System.Drawing.Point(85, 538);
            this.BackButtonAddStu.Margin = new System.Windows.Forms.Padding(4);
            this.BackButtonAddStu.Name = "BackButtonAddStu";
            this.BackButtonAddStu.Size = new System.Drawing.Size(135, 39);
            this.BackButtonAddStu.TabIndex = 35;
            this.BackButtonAddStu.Text = "Back";
            this.BackButtonAddStu.UseVisualStyleBackColor = false;
            this.BackButtonAddStu.Click += new System.EventHandler(this.BackButtonAddStu_Click);
            // 
            // SubmitButtonAddStu
            // 
            this.SubmitButtonAddStu.BackColor = System.Drawing.Color.Yellow;
            this.SubmitButtonAddStu.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButtonAddStu.Location = new System.Drawing.Point(937, 538);
            this.SubmitButtonAddStu.Margin = new System.Windows.Forms.Padding(4);
            this.SubmitButtonAddStu.Name = "SubmitButtonAddStu";
            this.SubmitButtonAddStu.Size = new System.Drawing.Size(135, 39);
            this.SubmitButtonAddStu.TabIndex = 34;
            this.SubmitButtonAddStu.Text = "Submit";
            this.SubmitButtonAddStu.UseVisualStyleBackColor = false;
            this.SubmitButtonAddStu.Click += new System.EventHandler(this.SubmitButtonAddStu_Click);
            // 
            // TextBoxAddStuDepartment
            // 
            this.TextBoxAddStuDepartment.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxAddStuDepartment.Location = new System.Drawing.Point(562, 486);
            this.TextBoxAddStuDepartment.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxAddStuDepartment.Multiline = true;
            this.TextBoxAddStuDepartment.Name = "TextBoxAddStuDepartment";
            this.TextBoxAddStuDepartment.Size = new System.Drawing.Size(249, 38);
            this.TextBoxAddStuDepartment.TabIndex = 32;
            // 
            // TextBoxAddStuCity
            // 
            this.TextBoxAddStuCity.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxAddStuCity.Location = new System.Drawing.Point(562, 434);
            this.TextBoxAddStuCity.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxAddStuCity.Multiline = true;
            this.TextBoxAddStuCity.Name = "TextBoxAddStuCity";
            this.TextBoxAddStuCity.Size = new System.Drawing.Size(249, 38);
            this.TextBoxAddStuCity.TabIndex = 32;
            // 
            // TextBoxAddStuNoOfCourses
            // 
            this.TextBoxAddStuNoOfCourses.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxAddStuNoOfCourses.Location = new System.Drawing.Point(562, 386);
            this.TextBoxAddStuNoOfCourses.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxAddStuNoOfCourses.Multiline = true;
            this.TextBoxAddStuNoOfCourses.Name = "TextBoxAddStuNoOfCourses";
            this.TextBoxAddStuNoOfCourses.Size = new System.Drawing.Size(249, 38);
            this.TextBoxAddStuNoOfCourses.TabIndex = 32;
            // 
            // TextBoxAddStuSemNo
            // 
            this.TextBoxAddStuSemNo.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxAddStuSemNo.Location = new System.Drawing.Point(562, 340);
            this.TextBoxAddStuSemNo.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxAddStuSemNo.Multiline = true;
            this.TextBoxAddStuSemNo.Name = "TextBoxAddStuSemNo";
            this.TextBoxAddStuSemNo.Size = new System.Drawing.Size(45, 38);
            this.TextBoxAddStuSemNo.TabIndex = 32;
            // 
            // TextBoxAddStuBirthDate
            // 
            this.TextBoxAddStuBirthDate.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxAddStuBirthDate.Location = new System.Drawing.Point(562, 245);
            this.TextBoxAddStuBirthDate.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxAddStuBirthDate.Multiline = true;
            this.TextBoxAddStuBirthDate.Name = "TextBoxAddStuBirthDate";
            this.TextBoxAddStuBirthDate.Size = new System.Drawing.Size(249, 38);
            this.TextBoxAddStuBirthDate.TabIndex = 32;
            // 
            // TextBoxAddStuLastName
            // 
            this.TextBoxAddStuLastName.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxAddStuLastName.Location = new System.Drawing.Point(562, 190);
            this.TextBoxAddStuLastName.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxAddStuLastName.Multiline = true;
            this.TextBoxAddStuLastName.Name = "TextBoxAddStuLastName";
            this.TextBoxAddStuLastName.Size = new System.Drawing.Size(249, 38);
            this.TextBoxAddStuLastName.TabIndex = 32;
            this.TextBoxAddStuLastName.TextChanged += new System.EventHandler(this.TextBoxAddStuLastName_TextChanged);
            // 
            // TextBoxAddStuFirstName
            // 
            this.TextBoxAddStuFirstName.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxAddStuFirstName.Location = new System.Drawing.Point(562, 138);
            this.TextBoxAddStuFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxAddStuFirstName.Multiline = true;
            this.TextBoxAddStuFirstName.Name = "TextBoxAddStuFirstName";
            this.TextBoxAddStuFirstName.Size = new System.Drawing.Size(249, 38);
            this.TextBoxAddStuFirstName.TabIndex = 32;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tabPage4.Controls.Add(this.buttonLogOut);
            this.tabPage4.Controls.Add(this.labelDT);
            this.tabPage4.Controls.Add(this.buttonGrades);
            this.tabPage4.Controls.Add(this.buttonAddHabit);
            this.tabPage4.Controls.Add(this.buttonAddCareer);
            this.tabPage4.Controls.Add(this.buttonAddActivity);
            this.tabPage4.Controls.Add(this.buttonAddCourse);
            this.tabPage4.Controls.Add(this.label78);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(1165, 617);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Main Menu";
            // 
            // buttonLogOut
            // 
            this.buttonLogOut.BackColor = System.Drawing.Color.Black;
            this.buttonLogOut.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogOut.ForeColor = System.Drawing.Color.Yellow;
            this.buttonLogOut.Location = new System.Drawing.Point(40, 517);
            this.buttonLogOut.Margin = new System.Windows.Forms.Padding(4);
            this.buttonLogOut.Name = "buttonLogOut";
            this.buttonLogOut.Size = new System.Drawing.Size(174, 66);
            this.buttonLogOut.TabIndex = 43;
            this.buttonLogOut.Text = "LOG OUT";
            this.buttonLogOut.UseVisualStyleBackColor = false;
            this.buttonLogOut.Click += new System.EventHandler(this.buttonLogOut_Click);
            // 
            // labelDT
            // 
            this.labelDT.AutoSize = true;
            this.labelDT.Font = new System.Drawing.Font("Segoe Script", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDT.ForeColor = System.Drawing.Color.Yellow;
            this.labelDT.Location = new System.Drawing.Point(300, 517);
            this.labelDT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDT.Name = "labelDT";
            this.labelDT.Size = new System.Drawing.Size(253, 67);
            this.labelDT.TabIndex = 42;
            this.labelDT.Text = "Date Time";
            // 
            // buttonGrades
            // 
            this.buttonGrades.BackColor = System.Drawing.Color.Black;
            this.buttonGrades.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGrades.ForeColor = System.Drawing.Color.Yellow;
            this.buttonGrades.Location = new System.Drawing.Point(621, 354);
            this.buttonGrades.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGrades.Name = "buttonGrades";
            this.buttonGrades.Size = new System.Drawing.Size(176, 142);
            this.buttonGrades.TabIndex = 41;
            this.buttonGrades.Text = " GRADES  ";
            this.buttonGrades.UseVisualStyleBackColor = false;
            this.buttonGrades.Click += new System.EventHandler(this.buttonGrades_Click);
            // 
            // buttonAddHabit
            // 
            this.buttonAddHabit.BackColor = System.Drawing.Color.Black;
            this.buttonAddHabit.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddHabit.ForeColor = System.Drawing.Color.Yellow;
            this.buttonAddHabit.Location = new System.Drawing.Point(715, 183);
            this.buttonAddHabit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddHabit.Name = "buttonAddHabit";
            this.buttonAddHabit.Size = new System.Drawing.Size(174, 146);
            this.buttonAddHabit.TabIndex = 41;
            this.buttonAddHabit.Text = "ADD HABIT";
            this.buttonAddHabit.UseVisualStyleBackColor = false;
            this.buttonAddHabit.Click += new System.EventHandler(this.buttonAddHabit_Click);
            // 
            // buttonAddCareer
            // 
            this.buttonAddCareer.BackColor = System.Drawing.Color.Black;
            this.buttonAddCareer.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddCareer.ForeColor = System.Drawing.Color.Yellow;
            this.buttonAddCareer.Location = new System.Drawing.Point(503, 183);
            this.buttonAddCareer.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddCareer.Name = "buttonAddCareer";
            this.buttonAddCareer.Size = new System.Drawing.Size(176, 146);
            this.buttonAddCareer.TabIndex = 41;
            this.buttonAddCareer.Text = "ADD CAREER";
            this.buttonAddCareer.UseVisualStyleBackColor = false;
            this.buttonAddCareer.Click += new System.EventHandler(this.buttonAddCareer_Click);
            // 
            // buttonAddActivity
            // 
            this.buttonAddActivity.BackColor = System.Drawing.Color.Black;
            this.buttonAddActivity.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddActivity.ForeColor = System.Drawing.Color.Yellow;
            this.buttonAddActivity.Location = new System.Drawing.Point(396, 354);
            this.buttonAddActivity.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddActivity.Name = "buttonAddActivity";
            this.buttonAddActivity.Size = new System.Drawing.Size(174, 142);
            this.buttonAddActivity.TabIndex = 41;
            this.buttonAddActivity.Text = "ADD ACTIVITY";
            this.buttonAddActivity.UseVisualStyleBackColor = false;
            this.buttonAddActivity.Click += new System.EventHandler(this.buttonAddActivity_Click);
            // 
            // buttonAddCourse
            // 
            this.buttonAddCourse.BackColor = System.Drawing.Color.Black;
            this.buttonAddCourse.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddCourse.ForeColor = System.Drawing.Color.Yellow;
            this.buttonAddCourse.Location = new System.Drawing.Point(293, 183);
            this.buttonAddCourse.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddCourse.Name = "buttonAddCourse";
            this.buttonAddCourse.Size = new System.Drawing.Size(174, 146);
            this.buttonAddCourse.TabIndex = 41;
            this.buttonAddCourse.Text = "ADD COURSE";
            this.buttonAddCourse.UseVisualStyleBackColor = false;
            this.buttonAddCourse.Click += new System.EventHandler(this.buttonAddCourse_Click);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.ForeColor = System.Drawing.Color.Yellow;
            this.label78.Location = new System.Drawing.Point(357, 64);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(440, 90);
            this.label78.TabIndex = 39;
            this.label78.Text = "Main Menu";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.button1);
            this.tabPage5.Controls.Add(this.student_course);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Controls.Add(this.dataGridView_StudentCourses);
            this.tabPage5.Controls.Add(this.dataGridViewAllCourses);
            this.tabPage5.Controls.Add(this.label126);
            this.tabPage5.Controls.Add(this.label125);
            this.tabPage5.Controls.Add(this.textBox4);
            this.tabPage5.Controls.Add(this.label124);
            this.tabPage5.Controls.Add(this.AddQuizMarksButton);
            this.tabPage5.Controls.Add(this.AddAssiMarksButton);
            this.tabPage5.Controls.Add(this.AddExamMarks);
            this.tabPage5.Controls.Add(this.CourseIDtextBoxAddcourse);
            this.tabPage5.Controls.Add(this.textBox3);
            this.tabPage5.Controls.Add(this.label3);
            this.tabPage5.Controls.Add(this.label2);
            this.tabPage5.Controls.Add(this.label4);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Controls.Add(this.label7);
            this.tabPage5.Controls.Add(this.InstructorEmailtextBoxAddcourse);
            this.tabPage5.Controls.Add(this.InstructorNametextBoxAddcourse);
            this.tabPage5.Controls.Add(this.CourseNametextBoxAddcourse);
            this.tabPage5.Controls.Add(this.CreditHourstextBoxAddcourse);
            this.tabPage5.Controls.Add(this.label8);
            this.tabPage5.Controls.Add(this.InstructorMobileNotextBoxAddcourse);
            this.tabPage5.Controls.Add(this.label9);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Controls.Add(this.label10);
            this.tabPage5.Controls.Add(this.submitButtonAddCourse);
            this.tabPage5.Controls.Add(this.MAinMenuButtonAddCourse);
            this.tabPage5.Controls.Add(this.label66);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage5.Size = new System.Drawing.Size(1165, 617);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Add Course";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Green;
            this.button2.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(861, 559);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(247, 50);
            this.button2.TabIndex = 125;
            this.button2.Text = "Course Result";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(1015, 232);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 50);
            this.button1.TabIndex = 124;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // student_course
            // 
            this.student_course.ForeColor = System.Drawing.Color.Green;
            this.student_course.Location = new System.Drawing.Point(829, 248);
            this.student_course.Margin = new System.Windows.Forms.Padding(4);
            this.student_course.Name = "student_course";
            this.student_course.Size = new System.Drawing.Size(159, 22);
            this.student_course.TabIndex = 123;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(611, 235);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 36);
            this.label5.TabIndex = 122;
            this.label5.Text = "Your Courses";
            // 
            // dataGridView_StudentCourses
            // 
            this.dataGridView_StudentCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_StudentCourses.Location = new System.Drawing.Point(592, 298);
            this.dataGridView_StudentCourses.Name = "dataGridView_StudentCourses";
            this.dataGridView_StudentCourses.RowHeadersWidth = 51;
            this.dataGridView_StudentCourses.RowTemplate.Height = 24;
            this.dataGridView_StudentCourses.Size = new System.Drawing.Size(538, 85);
            this.dataGridView_StudentCourses.TabIndex = 121;
            // 
            // dataGridViewAllCourses
            // 
            this.dataGridViewAllCourses.AllowUserToAddRows = false;
            this.dataGridViewAllCourses.AllowUserToDeleteRows = false;
            this.dataGridViewAllCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAllCourses.Location = new System.Drawing.Point(591, 113);
            this.dataGridViewAllCourses.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewAllCourses.Name = "dataGridViewAllCourses";
            this.dataGridViewAllCourses.ReadOnly = true;
            this.dataGridViewAllCourses.RowHeadersWidth = 62;
            this.dataGridViewAllCourses.RowTemplate.Height = 28;
            this.dataGridViewAllCourses.Size = new System.Drawing.Size(539, 94);
            this.dataGridViewAllCourses.TabIndex = 120;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label126.ForeColor = System.Drawing.Color.Green;
            this.label126.Location = new System.Drawing.Point(744, 386);
            this.label126.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(231, 36);
            this.label126.TabIndex = 119;
            this.label126.Text = "Add details for:";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.ForeColor = System.Drawing.Color.Green;
            this.label125.Location = new System.Drawing.Point(701, 437);
            this.label125.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(120, 29);
            this.label125.TabIndex = 118;
            this.label125.Text = "Course ID";
            // 
            // textBox4
            // 
            this.textBox4.ForeColor = System.Drawing.Color.Green;
            this.textBox4.Location = new System.Drawing.Point(861, 437);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(200, 22);
            this.textBox4.TabIndex = 117;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.ForeColor = System.Drawing.Color.Green;
            this.label124.Location = new System.Drawing.Point(770, 59);
            this.label124.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(273, 36);
            this.label124.TabIndex = 116;
            this.label124.Text = "Available Courses";
            // 
            // AddQuizMarksButton
            // 
            this.AddQuizMarksButton.BackColor = System.Drawing.Color.Green;
            this.AddQuizMarksButton.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddQuizMarksButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.AddQuizMarksButton.Location = new System.Drawing.Point(574, 492);
            this.AddQuizMarksButton.Margin = new System.Windows.Forms.Padding(4);
            this.AddQuizMarksButton.Name = "AddQuizMarksButton";
            this.AddQuizMarksButton.Size = new System.Drawing.Size(247, 50);
            this.AddQuizMarksButton.TabIndex = 111;
            this.AddQuizMarksButton.Text = "Add Quiz Details";
            this.AddQuizMarksButton.UseVisualStyleBackColor = false;
            this.AddQuizMarksButton.Click += new System.EventHandler(this.AddQuizMarksButton_Click);
            // 
            // AddAssiMarksButton
            // 
            this.AddAssiMarksButton.BackColor = System.Drawing.Color.Green;
            this.AddAssiMarksButton.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddAssiMarksButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.AddAssiMarksButton.Location = new System.Drawing.Point(861, 492);
            this.AddAssiMarksButton.Margin = new System.Windows.Forms.Padding(4);
            this.AddAssiMarksButton.Name = "AddAssiMarksButton";
            this.AddAssiMarksButton.Size = new System.Drawing.Size(247, 50);
            this.AddAssiMarksButton.TabIndex = 112;
            this.AddAssiMarksButton.Text = "Add Assignment Details";
            this.AddAssiMarksButton.UseVisualStyleBackColor = false;
            this.AddAssiMarksButton.Click += new System.EventHandler(this.AddAssiMarksButton_Click);
            // 
            // AddExamMarks
            // 
            this.AddExamMarks.BackColor = System.Drawing.Color.Green;
            this.AddExamMarks.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddExamMarks.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.AddExamMarks.Location = new System.Drawing.Point(574, 559);
            this.AddExamMarks.Margin = new System.Windows.Forms.Padding(4);
            this.AddExamMarks.Name = "AddExamMarks";
            this.AddExamMarks.Size = new System.Drawing.Size(247, 50);
            this.AddExamMarks.TabIndex = 113;
            this.AddExamMarks.Text = "Add Exam Details";
            this.AddExamMarks.UseVisualStyleBackColor = false;
            this.AddExamMarks.Click += new System.EventHandler(this.AddExamMarks_Click);
            // 
            // CourseIDtextBoxAddcourse
            // 
            this.CourseIDtextBoxAddcourse.ForeColor = System.Drawing.Color.Green;
            this.CourseIDtextBoxAddcourse.Location = new System.Drawing.Point(315, 140);
            this.CourseIDtextBoxAddcourse.Margin = new System.Windows.Forms.Padding(4);
            this.CourseIDtextBoxAddcourse.Name = "CourseIDtextBoxAddcourse";
            this.CourseIDtextBoxAddcourse.Size = new System.Drawing.Size(200, 22);
            this.CourseIDtextBoxAddcourse.TabIndex = 110;
            // 
            // textBox3
            // 
            this.textBox3.ForeColor = System.Drawing.Color.Green;
            this.textBox3.Location = new System.Drawing.Point(295, 474);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(200, 22);
            this.textBox3.TabIndex = 108;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(154, 386);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 31);
            this.label3.TabIndex = 107;
            this.label3.Text = "Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(182, 272);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(256, 36);
            this.label2.TabIndex = 103;
            this.label2.Text = "Instructor Details";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Green;
            this.label4.Location = new System.Drawing.Point(183, 73);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(256, 36);
            this.label4.TabIndex = 103;
            this.label4.Text = "Add New Course";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Green;
            this.label6.Location = new System.Drawing.Point(31, 428);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(196, 31);
            this.label6.TabIndex = 105;
            this.label6.Text = "Mobile Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Green;
            this.label7.Location = new System.Drawing.Point(150, 339);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 31);
            this.label7.TabIndex = 106;
            this.label7.Text = "Name";
            // 
            // InstructorEmailtextBoxAddcourse
            // 
            this.InstructorEmailtextBoxAddcourse.ForeColor = System.Drawing.Color.Green;
            this.InstructorEmailtextBoxAddcourse.Location = new System.Drawing.Point(295, 386);
            this.InstructorEmailtextBoxAddcourse.Margin = new System.Windows.Forms.Padding(4);
            this.InstructorEmailtextBoxAddcourse.Name = "InstructorEmailtextBoxAddcourse";
            this.InstructorEmailtextBoxAddcourse.Size = new System.Drawing.Size(200, 22);
            this.InstructorEmailtextBoxAddcourse.TabIndex = 102;
            // 
            // InstructorNametextBoxAddcourse
            // 
            this.InstructorNametextBoxAddcourse.ForeColor = System.Drawing.Color.Green;
            this.InstructorNametextBoxAddcourse.Location = new System.Drawing.Point(295, 339);
            this.InstructorNametextBoxAddcourse.Margin = new System.Windows.Forms.Padding(4);
            this.InstructorNametextBoxAddcourse.Name = "InstructorNametextBoxAddcourse";
            this.InstructorNametextBoxAddcourse.Size = new System.Drawing.Size(200, 22);
            this.InstructorNametextBoxAddcourse.TabIndex = 101;
            // 
            // CourseNametextBoxAddcourse
            // 
            this.CourseNametextBoxAddcourse.ForeColor = System.Drawing.Color.Green;
            this.CourseNametextBoxAddcourse.Location = new System.Drawing.Point(315, 220);
            this.CourseNametextBoxAddcourse.Margin = new System.Windows.Forms.Padding(4);
            this.CourseNametextBoxAddcourse.Name = "CourseNametextBoxAddcourse";
            this.CourseNametextBoxAddcourse.Size = new System.Drawing.Size(200, 22);
            this.CourseNametextBoxAddcourse.TabIndex = 102;
            // 
            // CreditHourstextBoxAddcourse
            // 
            this.CreditHourstextBoxAddcourse.ForeColor = System.Drawing.Color.Green;
            this.CreditHourstextBoxAddcourse.Location = new System.Drawing.Point(315, 178);
            this.CreditHourstextBoxAddcourse.Margin = new System.Windows.Forms.Padding(4);
            this.CreditHourstextBoxAddcourse.Name = "CreditHourstextBoxAddcourse";
            this.CreditHourstextBoxAddcourse.Size = new System.Drawing.Size(200, 22);
            this.CreditHourstextBoxAddcourse.TabIndex = 101;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Green;
            this.label8.Location = new System.Drawing.Point(55, 220);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(211, 29);
            this.label8.TabIndex = 100;
            this.label8.Text = "Add Course Name";
            // 
            // InstructorMobileNotextBoxAddcourse
            // 
            this.InstructorMobileNotextBoxAddcourse.ForeColor = System.Drawing.Color.Green;
            this.InstructorMobileNotextBoxAddcourse.Location = new System.Drawing.Point(295, 428);
            this.InstructorMobileNotextBoxAddcourse.Margin = new System.Windows.Forms.Padding(4);
            this.InstructorMobileNotextBoxAddcourse.Name = "InstructorMobileNotextBoxAddcourse";
            this.InstructorMobileNotextBoxAddcourse.Size = new System.Drawing.Size(200, 22);
            this.InstructorMobileNotextBoxAddcourse.TabIndex = 99;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Green;
            this.label9.Location = new System.Drawing.Point(151, 134);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 29);
            this.label9.TabIndex = 98;
            this.label9.Text = "Course ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(150, 467);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 31);
            this.label1.TabIndex = 97;
            this.label1.Text = "Office";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Green;
            this.label10.Location = new System.Drawing.Point(115, 178);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(155, 29);
            this.label10.TabIndex = 97;
            this.label10.Text = "Credit_Hours";
            // 
            // submitButtonAddCourse
            // 
            this.submitButtonAddCourse.BackColor = System.Drawing.Color.Green;
            this.submitButtonAddCourse.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitButtonAddCourse.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.submitButtonAddCourse.Location = new System.Drawing.Point(189, 514);
            this.submitButtonAddCourse.Margin = new System.Windows.Forms.Padding(4);
            this.submitButtonAddCourse.Name = "submitButtonAddCourse";
            this.submitButtonAddCourse.Size = new System.Drawing.Size(128, 50);
            this.submitButtonAddCourse.TabIndex = 93;
            this.submitButtonAddCourse.Text = "Submit";
            this.submitButtonAddCourse.UseVisualStyleBackColor = false;
            this.submitButtonAddCourse.Click += new System.EventHandler(this.submitButtonAddCourse_Click);
            // 
            // MAinMenuButtonAddCourse
            // 
            this.MAinMenuButtonAddCourse.BackColor = System.Drawing.Color.Green;
            this.MAinMenuButtonAddCourse.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MAinMenuButtonAddCourse.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.MAinMenuButtonAddCourse.Location = new System.Drawing.Point(170, 572);
            this.MAinMenuButtonAddCourse.Margin = new System.Windows.Forms.Padding(4);
            this.MAinMenuButtonAddCourse.Name = "MAinMenuButtonAddCourse";
            this.MAinMenuButtonAddCourse.Size = new System.Drawing.Size(160, 50);
            this.MAinMenuButtonAddCourse.TabIndex = 93;
            this.MAinMenuButtonAddCourse.Text = "Main Menu";
            this.MAinMenuButtonAddCourse.UseVisualStyleBackColor = false;
            this.MAinMenuButtonAddCourse.Click += new System.EventHandler(this.MAinMenuButtonAddCourse_Click);
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.Green;
            this.label66.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label66.Location = new System.Drawing.Point(-8, 0);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label66.Size = new System.Drawing.Size(1176, 42);
            this.label66.TabIndex = 54;
            this.label66.Text = "                         ADD COURSE";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Salmon;
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.Deadline);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.title);
            this.tabPage6.Controls.Add(this.textBox6);
            this.tabPage6.Controls.Add(this.textBox5);
            this.tabPage6.Controls.Add(this.textBox1);
            this.tabPage6.Controls.Add(this.label67);
            this.tabPage6.Controls.Add(this.textBoxJobTimePeriod);
            this.tabPage6.Controls.Add(this.label58);
            this.tabPage6.Controls.Add(this.label61);
            this.tabPage6.Controls.Add(this.textBoxProjectCompany);
            this.tabPage6.Controls.Add(this.label62);
            this.tabPage6.Controls.Add(this.label63);
            this.tabPage6.Controls.Add(this.textBoxJobID);
            this.tabPage6.Controls.Add(this.textBoxProjectTimePeriod);
            this.tabPage6.Controls.Add(this.label50);
            this.tabPage6.Controls.Add(this.label53);
            this.tabPage6.Controls.Add(this.textBoxJobCompany);
            this.tabPage6.Controls.Add(this.label55);
            this.tabPage6.Controls.Add(this.label56);
            this.tabPage6.Controls.Add(this.textBoxProjectID);
            this.tabPage6.Controls.Add(this.checkBoxJobApplication);
            this.tabPage6.Controls.Add(this.checkBoxProject);
            this.tabPage6.Controls.Add(this.checkBoxInternship);
            this.tabPage6.Controls.Add(this.textBoxPlannerID);
            this.tabPage6.Controls.Add(this.label46);
            this.tabPage6.Controls.Add(this.MainMenuButtonCareerPlanner);
            this.tabPage6.Controls.Add(this.submitButtonCareerPlanner);
            this.tabPage6.Controls.Add(this.label52);
            this.tabPage6.Controls.Add(this.label51);
            this.tabPage6.Controls.Add(this.label48);
            this.tabPage6.Controls.Add(this.textBoxInternshipTimePeriod);
            this.tabPage6.Controls.Add(this.label54);
            this.tabPage6.Controls.Add(this.label57);
            this.tabPage6.Controls.Add(this.textBoxInternshipCompany);
            this.tabPage6.Controls.Add(this.label44);
            this.tabPage6.Controls.Add(this.label59);
            this.tabPage6.Controls.Add(this.label60);
            this.tabPage6.Controls.Add(this.textBoxInternshipID);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(1165, 617);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Career Planner";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(771, 483);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 25);
            this.label14.TabIndex = 96;
            this.label14.Text = "Deadline";
            // 
            // Deadline
            // 
            this.Deadline.Location = new System.Drawing.Point(937, 483);
            this.Deadline.Margin = new System.Windows.Forms.Padding(4);
            this.Deadline.Name = "Deadline";
            this.Deadline.Size = new System.Drawing.Size(136, 22);
            this.Deadline.TabIndex = 95;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(395, 479);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 25);
            this.label11.TabIndex = 94;
            this.label11.Text = "Title";
            // 
            // title
            // 
            this.title.Location = new System.Drawing.Point(567, 483);
            this.title.Margin = new System.Windows.Forms.Padding(4);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(136, 22);
            this.title.TabIndex = 93;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(937, 338);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(210, 22);
            this.textBox6.TabIndex = 92;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(567, 332);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(214, 22);
            this.textBox5.TabIndex = 91;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(201, 334);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(199, 22);
            this.textBox1.TabIndex = 90;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label67.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label67.Location = new System.Drawing.Point(-4, 0);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label67.Size = new System.Drawing.Size(1176, 42);
            this.label67.TabIndex = 89;
            this.label67.Text = "                     CAREER PLANNER";
            // 
            // textBoxJobTimePeriod
            // 
            this.textBoxJobTimePeriod.Location = new System.Drawing.Point(940, 443);
            this.textBoxJobTimePeriod.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxJobTimePeriod.Name = "textBoxJobTimePeriod";
            this.textBoxJobTimePeriod.Size = new System.Drawing.Size(136, 22);
            this.textBoxJobTimePeriod.TabIndex = 86;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(820, 334);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(68, 25);
            this.label58.TabIndex = 82;
            this.label58.Text = "Status";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(768, 441);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(110, 25);
            this.label61.TabIndex = 83;
            this.label61.Text = "Experience";
            // 
            // textBoxProjectCompany
            // 
            this.textBoxProjectCompany.Location = new System.Drawing.Point(567, 389);
            this.textBoxProjectCompany.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxProjectCompany.Name = "textBoxProjectCompany";
            this.textBoxProjectCompany.Size = new System.Drawing.Size(214, 22);
            this.textBoxProjectCompany.TabIndex = 85;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(860, 282);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(31, 25);
            this.label62.TabIndex = 80;
            this.label62.Text = "ID";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(789, 386);
            this.label63.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(97, 25);
            this.label63.TabIndex = 84;
            this.label63.Text = "Company";
            // 
            // textBoxJobID
            // 
            this.textBoxJobID.Location = new System.Drawing.Point(940, 284);
            this.textBoxJobID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxJobID.Name = "textBoxJobID";
            this.textBoxJobID.Size = new System.Drawing.Size(75, 22);
            this.textBoxJobID.TabIndex = 81;
            // 
            // textBoxProjectTimePeriod
            // 
            this.textBoxProjectTimePeriod.Location = new System.Drawing.Point(567, 441);
            this.textBoxProjectTimePeriod.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxProjectTimePeriod.Name = "textBoxProjectTimePeriod";
            this.textBoxProjectTimePeriod.Size = new System.Drawing.Size(136, 22);
            this.textBoxProjectTimePeriod.TabIndex = 78;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(446, 332);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(68, 25);
            this.label50.TabIndex = 74;
            this.label50.Text = "Status";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(395, 438);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(117, 25);
            this.label53.TabIndex = 75;
            this.label53.Text = "Time Period";
            // 
            // textBoxJobCompany
            // 
            this.textBoxJobCompany.Location = new System.Drawing.Point(937, 389);
            this.textBoxJobCompany.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxJobCompany.Name = "textBoxJobCompany";
            this.textBoxJobCompany.Size = new System.Drawing.Size(210, 22);
            this.textBoxJobCompany.TabIndex = 77;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(487, 279);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(31, 25);
            this.label55.TabIndex = 72;
            this.label55.Text = "ID";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(416, 384);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(97, 25);
            this.label56.TabIndex = 76;
            this.label56.Text = "Company";
            // 
            // textBoxProjectID
            // 
            this.textBoxProjectID.Location = new System.Drawing.Point(567, 284);
            this.textBoxProjectID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxProjectID.Name = "textBoxProjectID";
            this.textBoxProjectID.Size = new System.Drawing.Size(75, 22);
            this.textBoxProjectID.TabIndex = 73;
            // 
            // checkBoxJobApplication
            // 
            this.checkBoxJobApplication.AutoSize = true;
            this.checkBoxJobApplication.Location = new System.Drawing.Point(1037, 219);
            this.checkBoxJobApplication.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxJobApplication.Name = "checkBoxJobApplication";
            this.checkBoxJobApplication.Size = new System.Drawing.Size(18, 17);
            this.checkBoxJobApplication.TabIndex = 70;
            this.checkBoxJobApplication.UseVisualStyleBackColor = true;
            // 
            // checkBoxProject
            // 
            this.checkBoxProject.AutoSize = true;
            this.checkBoxProject.Location = new System.Drawing.Point(611, 219);
            this.checkBoxProject.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxProject.Name = "checkBoxProject";
            this.checkBoxProject.Size = new System.Drawing.Size(18, 17);
            this.checkBoxProject.TabIndex = 70;
            this.checkBoxProject.UseVisualStyleBackColor = true;
            // 
            // checkBoxInternship
            // 
            this.checkBoxInternship.AutoSize = true;
            this.checkBoxInternship.Location = new System.Drawing.Point(279, 217);
            this.checkBoxInternship.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxInternship.Name = "checkBoxInternship";
            this.checkBoxInternship.Size = new System.Drawing.Size(18, 17);
            this.checkBoxInternship.TabIndex = 70;
            this.checkBoxInternship.UseVisualStyleBackColor = true;
            // 
            // textBoxPlannerID
            // 
            this.textBoxPlannerID.Location = new System.Drawing.Point(628, 106);
            this.textBoxPlannerID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPlannerID.Name = "textBoxPlannerID";
            this.textBoxPlannerID.Size = new System.Drawing.Size(87, 22);
            this.textBoxPlannerID.TabIndex = 69;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(445, 101);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(125, 29);
            this.label46.TabIndex = 67;
            this.label46.Text = "Planner ID";
            // 
            // MainMenuButtonCareerPlanner
            // 
            this.MainMenuButtonCareerPlanner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MainMenuButtonCareerPlanner.Font = new System.Drawing.Font("Microsoft PhagsPa", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuButtonCareerPlanner.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MainMenuButtonCareerPlanner.Location = new System.Drawing.Point(93, 523);
            this.MainMenuButtonCareerPlanner.Margin = new System.Windows.Forms.Padding(4);
            this.MainMenuButtonCareerPlanner.Name = "MainMenuButtonCareerPlanner";
            this.MainMenuButtonCareerPlanner.Size = new System.Drawing.Size(178, 42);
            this.MainMenuButtonCareerPlanner.TabIndex = 64;
            this.MainMenuButtonCareerPlanner.Text = "Main Menu";
            this.MainMenuButtonCareerPlanner.UseVisualStyleBackColor = false;
            this.MainMenuButtonCareerPlanner.Click += new System.EventHandler(this.MainMenuButtonCareerPlanner_Click);
            // 
            // submitButtonCareerPlanner
            // 
            this.submitButtonCareerPlanner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.submitButtonCareerPlanner.Font = new System.Drawing.Font("Microsoft PhagsPa", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitButtonCareerPlanner.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.submitButtonCareerPlanner.Location = new System.Drawing.Point(937, 523);
            this.submitButtonCareerPlanner.Margin = new System.Windows.Forms.Padding(4);
            this.submitButtonCareerPlanner.Name = "submitButtonCareerPlanner";
            this.submitButtonCareerPlanner.Size = new System.Drawing.Size(136, 43);
            this.submitButtonCareerPlanner.TabIndex = 41;
            this.submitButtonCareerPlanner.Text = "Submit";
            this.submitButtonCareerPlanner.UseVisualStyleBackColor = false;
            this.submitButtonCareerPlanner.Click += new System.EventHandler(this.submitButtonCareerPlanner_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(797, 208);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(213, 31);
            this.label52.TabIndex = 43;
            this.label52.Text = "Job Application";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(485, 208);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(106, 31);
            this.label51.TabIndex = 43;
            this.label51.Text = "Project";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(116, 206);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(144, 31);
            this.label48.TabIndex = 43;
            this.label48.Text = "Internship";
            // 
            // textBoxInternshipTimePeriod
            // 
            this.textBoxInternshipTimePeriod.Location = new System.Drawing.Point(201, 441);
            this.textBoxInternshipTimePeriod.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxInternshipTimePeriod.Name = "textBoxInternshipTimePeriod";
            this.textBoxInternshipTimePeriod.Size = new System.Drawing.Size(136, 22);
            this.textBoxInternshipTimePeriod.TabIndex = 59;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(82, 332);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(68, 25);
            this.label54.TabIndex = 56;
            this.label54.Text = "Status";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(29, 438);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(117, 25);
            this.label57.TabIndex = 56;
            this.label57.Text = "Time Period";
            // 
            // textBoxInternshipCompany
            // 
            this.textBoxInternshipCompany.Location = new System.Drawing.Point(201, 386);
            this.textBoxInternshipCompany.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxInternshipCompany.Name = "textBoxInternshipCompany";
            this.textBoxInternshipCompany.Size = new System.Drawing.Size(199, 22);
            this.textBoxInternshipCompany.TabIndex = 58;
            // 
            // label44
            // 
            this.label44.Location = new System.Drawing.Point(0, 0);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(133, 28);
            this.label44.TabIndex = 88;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(117, 279);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(31, 25);
            this.label59.TabIndex = 47;
            this.label59.Text = "ID";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(51, 384);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(97, 25);
            this.label60.TabIndex = 57;
            this.label60.Text = "Company";
            // 
            // textBoxInternshipID
            // 
            this.textBoxInternshipID.Location = new System.Drawing.Point(201, 282);
            this.textBoxInternshipID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxInternshipID.Name = "textBoxInternshipID";
            this.textBoxInternshipID.Size = new System.Drawing.Size(75, 22);
            this.textBoxInternshipID.TabIndex = 52;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tabPage7.Controls.Add(this.SubmitButtonHabit);
            this.tabPage7.Controls.Add(this.dataGridView_StudentHabbit);
            this.tabPage7.Controls.Add(this.dataGridViewAllHabts);
            this.tabPage7.Controls.Add(this.textBox7);
            this.tabPage7.Controls.Add(this.label68);
            this.tabPage7.Controls.Add(this.MainMenuButtonHabit);
            this.tabPage7.Controls.Add(this.textBoxHabitID);
            this.tabPage7.Controls.Add(this.textBoxHabitName);
            this.tabPage7.Controls.Add(this.label38);
            this.tabPage7.Controls.Add(this.label39);
            this.tabPage7.Controls.Add(this.label40);
            this.tabPage7.Controls.Add(this.label42);
            this.tabPage7.Controls.Add(this.label43);
            this.tabPage7.Controls.Add(this.textBoxHabitTimeRemaining);
            this.tabPage7.Controls.Add(this.textBoxHabitTimeAllocated);
            this.tabPage7.Controls.Add(this.label32);
            this.tabPage7.Controls.Add(this.textBoxHabitDuration);
            this.tabPage7.Controls.Add(this.label45);
            this.tabPage7.Controls.Add(this.label49);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage7.Size = new System.Drawing.Size(1165, 617);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Habit";
            // 
            // SubmitButtonHabit
            // 
            this.SubmitButtonHabit.BackColor = System.Drawing.Color.DarkRed;
            this.SubmitButtonHabit.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButtonHabit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.SubmitButtonHabit.Location = new System.Drawing.Point(474, 276);
            this.SubmitButtonHabit.Margin = new System.Windows.Forms.Padding(4);
            this.SubmitButtonHabit.Name = "SubmitButtonHabit";
            this.SubmitButtonHabit.Size = new System.Drawing.Size(135, 50);
            this.SubmitButtonHabit.TabIndex = 98;
            this.SubmitButtonHabit.Text = "Submit";
            this.SubmitButtonHabit.UseVisualStyleBackColor = false;
            this.SubmitButtonHabit.Click += new System.EventHandler(this.SubmitButtonHabit_Click_1);
            // 
            // dataGridView_StudentHabbit
            // 
            this.dataGridView_StudentHabbit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_StudentHabbit.Location = new System.Drawing.Point(121, 371);
            this.dataGridView_StudentHabbit.Name = "dataGridView_StudentHabbit";
            this.dataGridView_StudentHabbit.RowHeadersWidth = 51;
            this.dataGridView_StudentHabbit.RowTemplate.Height = 24;
            this.dataGridView_StudentHabbit.Size = new System.Drawing.Size(905, 163);
            this.dataGridView_StudentHabbit.TabIndex = 97;
            // 
            // dataGridViewAllHabts
            // 
            this.dataGridViewAllHabts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAllHabts.Location = new System.Drawing.Point(397, 57);
            this.dataGridViewAllHabts.Name = "dataGridViewAllHabts";
            this.dataGridViewAllHabts.RowHeadersWidth = 51;
            this.dataGridViewAllHabts.RowTemplate.Height = 24;
            this.dataGridViewAllHabts.Size = new System.Drawing.Size(310, 172);
            this.dataGridViewAllHabts.TabIndex = 96;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(943, 106);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(200, 22);
            this.textBox7.TabIndex = 94;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.Color.Maroon;
            this.label68.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label68.Location = new System.Drawing.Point(-8, 0);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label68.Size = new System.Drawing.Size(1176, 42);
            this.label68.TabIndex = 93;
            this.label68.Text = "                              HABITS";
            // 
            // MainMenuButtonHabit
            // 
            this.MainMenuButtonHabit.BackColor = System.Drawing.Color.DarkRed;
            this.MainMenuButtonHabit.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuButtonHabit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.MainMenuButtonHabit.Location = new System.Drawing.Point(16, 544);
            this.MainMenuButtonHabit.Margin = new System.Windows.Forms.Padding(4);
            this.MainMenuButtonHabit.Name = "MainMenuButtonHabit";
            this.MainMenuButtonHabit.Size = new System.Drawing.Size(160, 50);
            this.MainMenuButtonHabit.TabIndex = 91;
            this.MainMenuButtonHabit.Text = "Main Menu";
            this.MainMenuButtonHabit.UseVisualStyleBackColor = false;
            this.MainMenuButtonHabit.Click += new System.EventHandler(this.MainMenuButtonHabit_Click);
            // 
            // textBoxHabitID
            // 
            this.textBoxHabitID.Location = new System.Drawing.Point(169, 119);
            this.textBoxHabitID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHabitID.Name = "textBoxHabitID";
            this.textBoxHabitID.Size = new System.Drawing.Size(200, 22);
            this.textBoxHabitID.TabIndex = 89;
            // 
            // textBoxHabitName
            // 
            this.textBoxHabitName.Location = new System.Drawing.Point(169, 169);
            this.textBoxHabitName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHabitName.Name = "textBoxHabitName";
            this.textBoxHabitName.Size = new System.Drawing.Size(200, 22);
            this.textBoxHabitName.TabIndex = 87;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label38.Location = new System.Drawing.Point(63, 119);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(98, 29);
            this.label38.TabIndex = 86;
            this.label38.Text = "Habit ID";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label39.Location = new System.Drawing.Point(833, 51);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(214, 36);
            this.label39.TabIndex = 82;
            this.label39.Text = "Add Old Habit";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label40.Location = new System.Drawing.Point(46, 65);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(228, 36);
            this.label40.TabIndex = 83;
            this.label40.Text = "Add New Habit";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label42.Location = new System.Drawing.Point(4, 169);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(157, 31);
            this.label42.TabIndex = 84;
            this.label42.Text = "Habit Name";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label43.Location = new System.Drawing.Point(779, 106);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(113, 31);
            this.label43.TabIndex = 85;
            this.label43.Text = "Habit ID";
            // 
            // textBoxHabitTimeRemaining
            // 
            this.textBoxHabitTimeRemaining.Location = new System.Drawing.Point(943, 195);
            this.textBoxHabitTimeRemaining.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHabitTimeRemaining.Name = "textBoxHabitTimeRemaining";
            this.textBoxHabitTimeRemaining.Size = new System.Drawing.Size(200, 22);
            this.textBoxHabitTimeRemaining.TabIndex = 81;
            // 
            // textBoxHabitTimeAllocated
            // 
            this.textBoxHabitTimeAllocated.Location = new System.Drawing.Point(943, 248);
            this.textBoxHabitTimeAllocated.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHabitTimeAllocated.Name = "textBoxHabitTimeAllocated";
            this.textBoxHabitTimeAllocated.Size = new System.Drawing.Size(200, 22);
            this.textBoxHabitTimeAllocated.TabIndex = 80;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label32.Location = new System.Drawing.Point(714, 189);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(191, 29);
            this.label32.TabIndex = 79;
            this.label32.Text = "Time Remaining";
            // 
            // textBoxHabitDuration
            // 
            this.textBoxHabitDuration.Location = new System.Drawing.Point(943, 148);
            this.textBoxHabitDuration.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHabitDuration.Name = "textBoxHabitDuration";
            this.textBoxHabitDuration.Size = new System.Drawing.Size(200, 22);
            this.textBoxHabitDuration.TabIndex = 76;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label45.Location = new System.Drawing.Point(805, 143);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(103, 29);
            this.label45.TabIndex = 74;
            this.label45.Text = "Duration";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label49.Location = new System.Drawing.Point(731, 242);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(175, 29);
            this.label49.TabIndex = 67;
            this.label49.Text = "Time Allocated";
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(125)))));
            this.tabPage8.Controls.Add(this.dataGridView_StudentActivity);
            this.tabPage8.Controls.Add(this.dataGridViewAllActivities);
            this.tabPage8.Controls.Add(this.status);
            this.tabPage8.Controls.Add(this.textBox8);
            this.tabPage8.Controls.Add(this.label69);
            this.tabPage8.Controls.Add(this.MainMenuButtonPersonalActivity);
            this.tabPage8.Controls.Add(this.SubmitButtonPersonalActivity);
            this.tabPage8.Controls.Add(this.textBoxPersonalActivityTime);
            this.tabPage8.Controls.Add(this.textBoxPersonalActivityID);
            this.tabPage8.Controls.Add(this.label29);
            this.tabPage8.Controls.Add(this.label30);
            this.tabPage8.Controls.Add(this.textBoxActivityName);
            this.tabPage8.Controls.Add(this.label36);
            this.tabPage8.Controls.Add(this.label35);
            this.tabPage8.Controls.Add(this.label34);
            this.tabPage8.Controls.Add(this.label37);
            this.tabPage8.Controls.Add(this.label33);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage8.Size = new System.Drawing.Size(1165, 617);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Personal Activity";
            // 
            // dataGridView_StudentActivity
            // 
            this.dataGridView_StudentActivity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_StudentActivity.Location = new System.Drawing.Point(164, 354);
            this.dataGridView_StudentActivity.Name = "dataGridView_StudentActivity";
            this.dataGridView_StudentActivity.RowHeadersWidth = 51;
            this.dataGridView_StudentActivity.RowTemplate.Height = 24;
            this.dataGridView_StudentActivity.Size = new System.Drawing.Size(804, 177);
            this.dataGridView_StudentActivity.TabIndex = 79;
            // 
            // dataGridViewAllActivities
            // 
            this.dataGridViewAllActivities.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAllActivities.Location = new System.Drawing.Point(404, 54);
            this.dataGridViewAllActivities.Name = "dataGridViewAllActivities";
            this.dataGridViewAllActivities.RowHeadersWidth = 51;
            this.dataGridViewAllActivities.RowTemplate.Height = 24;
            this.dataGridViewAllActivities.Size = new System.Drawing.Size(346, 169);
            this.dataGridViewAllActivities.TabIndex = 78;
            // 
            // status
            // 
            this.status.Location = new System.Drawing.Point(939, 155);
            this.status.Margin = new System.Windows.Forms.Padding(4);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(198, 22);
            this.status.TabIndex = 77;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(938, 110);
            this.textBox8.Margin = new System.Windows.Forms.Padding(4);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(198, 22);
            this.textBox8.TabIndex = 55;
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.Coral;
            this.label69.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label69.Location = new System.Drawing.Point(-8, 0);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label69.Size = new System.Drawing.Size(1176, 42);
            this.label69.TabIndex = 54;
            this.label69.Text = "                   PERSONAL  ACTIVTY";
            // 
            // MainMenuButtonPersonalActivity
            // 
            this.MainMenuButtonPersonalActivity.BackColor = System.Drawing.Color.Coral;
            this.MainMenuButtonPersonalActivity.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuButtonPersonalActivity.Location = new System.Drawing.Point(17, 554);
            this.MainMenuButtonPersonalActivity.Margin = new System.Windows.Forms.Padding(4);
            this.MainMenuButtonPersonalActivity.Name = "MainMenuButtonPersonalActivity";
            this.MainMenuButtonPersonalActivity.Size = new System.Drawing.Size(162, 50);
            this.MainMenuButtonPersonalActivity.TabIndex = 53;
            this.MainMenuButtonPersonalActivity.Text = "Main Menu";
            this.MainMenuButtonPersonalActivity.UseVisualStyleBackColor = false;
            this.MainMenuButtonPersonalActivity.Click += new System.EventHandler(this.MainMenuButtonPersonalActivity_Click);
            // 
            // SubmitButtonPersonalActivity
            // 
            this.SubmitButtonPersonalActivity.BackColor = System.Drawing.Color.Coral;
            this.SubmitButtonPersonalActivity.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButtonPersonalActivity.Location = new System.Drawing.Point(502, 235);
            this.SubmitButtonPersonalActivity.Margin = new System.Windows.Forms.Padding(4);
            this.SubmitButtonPersonalActivity.Name = "SubmitButtonPersonalActivity";
            this.SubmitButtonPersonalActivity.Size = new System.Drawing.Size(135, 50);
            this.SubmitButtonPersonalActivity.TabIndex = 52;
            this.SubmitButtonPersonalActivity.Text = "Submit";
            this.SubmitButtonPersonalActivity.UseVisualStyleBackColor = false;
            this.SubmitButtonPersonalActivity.Click += new System.EventHandler(this.SubmitButtonPersonalActivity_Click);
            // 
            // textBoxPersonalActivityTime
            // 
            this.textBoxPersonalActivityTime.Location = new System.Drawing.Point(939, 199);
            this.textBoxPersonalActivityTime.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPersonalActivityTime.Name = "textBoxPersonalActivityTime";
            this.textBoxPersonalActivityTime.Size = new System.Drawing.Size(198, 22);
            this.textBoxPersonalActivityTime.TabIndex = 51;
            // 
            // textBoxPersonalActivityID
            // 
            this.textBoxPersonalActivityID.Location = new System.Drawing.Point(196, 145);
            this.textBoxPersonalActivityID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPersonalActivityID.Name = "textBoxPersonalActivityID";
            this.textBoxPersonalActivityID.Size = new System.Drawing.Size(198, 22);
            this.textBoxPersonalActivityID.TabIndex = 50;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(757, 194);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(147, 29);
            this.label29.TabIndex = 49;
            this.label29.Text = "Time Period";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(64, 138);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(115, 29);
            this.label30.TabIndex = 48;
            this.label30.Text = "Activity ID";
            // 
            // textBoxActivityName
            // 
            this.textBoxActivityName.Location = new System.Drawing.Point(196, 188);
            this.textBoxActivityName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxActivityName.Name = "textBoxActivityName";
            this.textBoxActivityName.Size = new System.Drawing.Size(198, 22);
            this.textBoxActivityName.TabIndex = 45;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(833, 50);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(244, 36);
            this.label36.TabIndex = 43;
            this.label36.Text = "Add Old Activity";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(86, 70);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(258, 36);
            this.label35.TabIndex = 43;
            this.label35.Text = "Add New Activity";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(811, 146);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(92, 31);
            this.label34.TabIndex = 43;
            this.label34.Text = "Status";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(-2, 179);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(181, 31);
            this.label37.TabIndex = 43;
            this.label37.Text = "Activity Name";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(767, 101);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(137, 31);
            this.label33.TabIndex = 43;
            this.label33.Text = "Activity ID";
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.tabPage9.Controls.Add(this.Result);
            this.tabPage9.Controls.Add(this.gridallcourses);
            this.tabPage9.Controls.Add(this.CalculateGPAbutton);
            this.tabPage9.Controls.Add(this.MainMenuButtonGradesGPA);
            this.tabPage9.Controls.Add(this.SearchButtonGradesGPA);
            this.tabPage9.Controls.Add(this.label70);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage9.Size = new System.Drawing.Size(1165, 617);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Grades & GPA";
            // 
            // Result
            // 
            this.Result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Result.Location = new System.Drawing.Point(598, 459);
            this.Result.Name = "Result";
            this.Result.RowHeadersWidth = 51;
            this.Result.RowTemplate.Height = 24;
            this.Result.Size = new System.Drawing.Size(394, 59);
            this.Result.TabIndex = 155;
            // 
            // gridallcourses
            // 
            this.gridallcourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridallcourses.Location = new System.Drawing.Point(48, 138);
            this.gridallcourses.Name = "gridallcourses";
            this.gridallcourses.RowHeadersWidth = 51;
            this.gridallcourses.RowTemplate.Height = 24;
            this.gridallcourses.Size = new System.Drawing.Size(999, 173);
            this.gridallcourses.TabIndex = 154;
            // 
            // CalculateGPAbutton
            // 
            this.CalculateGPAbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.CalculateGPAbutton.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalculateGPAbutton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.CalculateGPAbutton.Location = new System.Drawing.Point(293, 459);
            this.CalculateGPAbutton.Margin = new System.Windows.Forms.Padding(4);
            this.CalculateGPAbutton.Name = "CalculateGPAbutton";
            this.CalculateGPAbutton.Size = new System.Drawing.Size(194, 50);
            this.CalculateGPAbutton.TabIndex = 153;
            this.CalculateGPAbutton.Text = "Calculate GPA";
            this.CalculateGPAbutton.UseVisualStyleBackColor = false;
            this.CalculateGPAbutton.Click += new System.EventHandler(this.CalculateGPAbutton_Click);
            // 
            // MainMenuButtonGradesGPA
            // 
            this.MainMenuButtonGradesGPA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.MainMenuButtonGradesGPA.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuButtonGradesGPA.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.MainMenuButtonGradesGPA.Location = new System.Drawing.Point(489, 550);
            this.MainMenuButtonGradesGPA.Margin = new System.Windows.Forms.Padding(4);
            this.MainMenuButtonGradesGPA.Name = "MainMenuButtonGradesGPA";
            this.MainMenuButtonGradesGPA.Size = new System.Drawing.Size(160, 50);
            this.MainMenuButtonGradesGPA.TabIndex = 95;
            this.MainMenuButtonGradesGPA.Text = "Main Menu";
            this.MainMenuButtonGradesGPA.UseVisualStyleBackColor = false;
            this.MainMenuButtonGradesGPA.Click += new System.EventHandler(this.MainMenuButtonGradesGPA_Click);
            // 
            // SearchButtonGradesGPA
            // 
            this.SearchButtonGradesGPA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.SearchButtonGradesGPA.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButtonGradesGPA.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.SearchButtonGradesGPA.Location = new System.Drawing.Point(438, 62);
            this.SearchButtonGradesGPA.Margin = new System.Windows.Forms.Padding(4);
            this.SearchButtonGradesGPA.Name = "SearchButtonGradesGPA";
            this.SearchButtonGradesGPA.Size = new System.Drawing.Size(264, 50);
            this.SearchButtonGradesGPA.TabIndex = 94;
            this.SearchButtonGradesGPA.Text = "View All Courses";
            this.SearchButtonGradesGPA.UseVisualStyleBackColor = false;
            this.SearchButtonGradesGPA.Click += new System.EventHandler(this.SearchButtonGradesGPA_Click);
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label70.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label70.Location = new System.Drawing.Point(-8, 0);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label70.Size = new System.Drawing.Size(1176, 42);
            this.label70.TabIndex = 33;
            this.label70.Text = "                    GRADES AND GPA";
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage11.Controls.Add(this.dataGridViewQuizzes);
            this.tabPage11.Controls.Add(this.QuizIDtextBoxQuiz);
            this.tabPage11.Controls.Add(this.label13);
            this.tabPage11.Controls.Add(this.StatustextBoxQuiz);
            this.tabPage11.Controls.Add(this.ObtainedMarkstextBoxQuiz);
            this.tabPage11.Controls.Add(this.label41);
            this.tabPage11.Controls.Add(this.label47);
            this.tabPage11.Controls.Add(this.SubmitbuttonAddQuiz);
            this.tabPage11.Controls.Add(this.BackbuttonAddQuiz);
            this.tabPage11.Controls.Add(this.label79);
            this.tabPage11.Location = new System.Drawing.Point(4, 25);
            this.tabPage11.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage11.Size = new System.Drawing.Size(1165, 617);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "Add Quiz Details";
            // 
            // dataGridViewQuizzes
            // 
            this.dataGridViewQuizzes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewQuizzes.Location = new System.Drawing.Point(46, 287);
            this.dataGridViewQuizzes.Name = "dataGridViewQuizzes";
            this.dataGridViewQuizzes.RowHeadersWidth = 51;
            this.dataGridViewQuizzes.RowTemplate.Height = 24;
            this.dataGridViewQuizzes.Size = new System.Drawing.Size(1075, 140);
            this.dataGridViewQuizzes.TabIndex = 130;
            // 
            // QuizIDtextBoxQuiz
            // 
            this.QuizIDtextBoxQuiz.ForeColor = System.Drawing.Color.Green;
            this.QuizIDtextBoxQuiz.Location = new System.Drawing.Point(594, 137);
            this.QuizIDtextBoxQuiz.Margin = new System.Windows.Forms.Padding(4);
            this.QuizIDtextBoxQuiz.Name = "QuizIDtextBoxQuiz";
            this.QuizIDtextBoxQuiz.Size = new System.Drawing.Size(95, 22);
            this.QuizIDtextBoxQuiz.TabIndex = 129;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Green;
            this.label13.Location = new System.Drawing.Point(477, 174);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 31);
            this.label13.TabIndex = 125;
            this.label13.Text = "Status";
            // 
            // StatustextBoxQuiz
            // 
            this.StatustextBoxQuiz.ForeColor = System.Drawing.Color.Green;
            this.StatustextBoxQuiz.Location = new System.Drawing.Point(594, 174);
            this.StatustextBoxQuiz.Margin = new System.Windows.Forms.Padding(4);
            this.StatustextBoxQuiz.Name = "StatustextBoxQuiz";
            this.StatustextBoxQuiz.Size = new System.Drawing.Size(136, 22);
            this.StatustextBoxQuiz.TabIndex = 122;
            // 
            // ObtainedMarkstextBoxQuiz
            // 
            this.ObtainedMarkstextBoxQuiz.ForeColor = System.Drawing.Color.Green;
            this.ObtainedMarkstextBoxQuiz.Location = new System.Drawing.Point(594, 222);
            this.ObtainedMarkstextBoxQuiz.Margin = new System.Windows.Forms.Padding(4);
            this.ObtainedMarkstextBoxQuiz.Name = "ObtainedMarkstextBoxQuiz";
            this.ObtainedMarkstextBoxQuiz.Size = new System.Drawing.Size(50, 22);
            this.ObtainedMarkstextBoxQuiz.TabIndex = 119;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Green;
            this.label41.Location = new System.Drawing.Point(478, 132);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(91, 29);
            this.label41.TabIndex = 116;
            this.label41.Text = "Quiz ID";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.Green;
            this.label47.Location = new System.Drawing.Point(377, 222);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(183, 29);
            this.label47.TabIndex = 115;
            this.label47.Text = "Obtained Marks";
            // 
            // SubmitbuttonAddQuiz
            // 
            this.SubmitbuttonAddQuiz.BackColor = System.Drawing.Color.Green;
            this.SubmitbuttonAddQuiz.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitbuttonAddQuiz.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.SubmitbuttonAddQuiz.Location = new System.Drawing.Point(830, 174);
            this.SubmitbuttonAddQuiz.Margin = new System.Windows.Forms.Padding(4);
            this.SubmitbuttonAddQuiz.Name = "SubmitbuttonAddQuiz";
            this.SubmitbuttonAddQuiz.Size = new System.Drawing.Size(128, 50);
            this.SubmitbuttonAddQuiz.TabIndex = 112;
            this.SubmitbuttonAddQuiz.Text = "Submit";
            this.SubmitbuttonAddQuiz.UseVisualStyleBackColor = false;
            this.SubmitbuttonAddQuiz.Click += new System.EventHandler(this.SubmitbuttonAddQuiz_Click);
            // 
            // BackbuttonAddQuiz
            // 
            this.BackbuttonAddQuiz.BackColor = System.Drawing.Color.Green;
            this.BackbuttonAddQuiz.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackbuttonAddQuiz.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackbuttonAddQuiz.Location = new System.Drawing.Point(162, 167);
            this.BackbuttonAddQuiz.Margin = new System.Windows.Forms.Padding(4);
            this.BackbuttonAddQuiz.Name = "BackbuttonAddQuiz";
            this.BackbuttonAddQuiz.Size = new System.Drawing.Size(108, 50);
            this.BackbuttonAddQuiz.TabIndex = 113;
            this.BackbuttonAddQuiz.Text = "Back";
            this.BackbuttonAddQuiz.UseVisualStyleBackColor = false;
            this.BackbuttonAddQuiz.Click += new System.EventHandler(this.BackbuttonAddQuiz_Click);
            // 
            // label79
            // 
            this.label79.BackColor = System.Drawing.Color.Green;
            this.label79.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label79.Location = new System.Drawing.Point(-8, 0);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label79.Size = new System.Drawing.Size(1176, 42);
            this.label79.TabIndex = 111;
            this.label79.Text = "                     ADD QUIZ DETAILS";
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage12.Controls.Add(this.dataGridViewAttempAssignment);
            this.tabPage12.Controls.Add(this.AssiIDtextBoxAddAssi);
            this.tabPage12.Controls.Add(this.label82);
            this.tabPage12.Controls.Add(this.label83);
            this.tabPage12.Controls.Add(this.StatustextBoxAddAssi);
            this.tabPage12.Controls.Add(this.ObtainedMarkstextBoxAddAssi);
            this.tabPage12.Controls.Add(this.label86);
            this.tabPage12.Controls.Add(this.label87);
            this.tabPage12.Controls.Add(this.SubmitbuttonAddAssi);
            this.tabPage12.Controls.Add(this.BackbuttonAddAssi);
            this.tabPage12.Controls.Add(this.label89);
            this.tabPage12.Location = new System.Drawing.Point(4, 25);
            this.tabPage12.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage12.Size = new System.Drawing.Size(1165, 617);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "Add Assignment Details";
            // 
            // dataGridViewAttempAssignment
            // 
            this.dataGridViewAttempAssignment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAttempAssignment.Location = new System.Drawing.Point(49, 306);
            this.dataGridViewAttempAssignment.Name = "dataGridViewAttempAssignment";
            this.dataGridViewAttempAssignment.RowHeadersWidth = 51;
            this.dataGridViewAttempAssignment.RowTemplate.Height = 24;
            this.dataGridViewAttempAssignment.Size = new System.Drawing.Size(1021, 150);
            this.dataGridViewAttempAssignment.TabIndex = 150;
            // 
            // AssiIDtextBoxAddAssi
            // 
            this.AssiIDtextBoxAddAssi.ForeColor = System.Drawing.Color.Green;
            this.AssiIDtextBoxAddAssi.Location = new System.Drawing.Point(590, 144);
            this.AssiIDtextBoxAddAssi.Margin = new System.Windows.Forms.Padding(4);
            this.AssiIDtextBoxAddAssi.Name = "AssiIDtextBoxAddAssi";
            this.AssiIDtextBoxAddAssi.Size = new System.Drawing.Size(95, 22);
            this.AssiIDtextBoxAddAssi.TabIndex = 149;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.ForeColor = System.Drawing.Color.Green;
            this.label82.Location = new System.Drawing.Point(524, 59);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(0, 36);
            this.label82.TabIndex = 144;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.ForeColor = System.Drawing.Color.Green;
            this.label83.Location = new System.Drawing.Point(483, 182);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(92, 31);
            this.label83.TabIndex = 145;
            this.label83.Text = "Status";
            // 
            // StatustextBoxAddAssi
            // 
            this.StatustextBoxAddAssi.ForeColor = System.Drawing.Color.Green;
            this.StatustextBoxAddAssi.Location = new System.Drawing.Point(590, 190);
            this.StatustextBoxAddAssi.Margin = new System.Windows.Forms.Padding(4);
            this.StatustextBoxAddAssi.Name = "StatustextBoxAddAssi";
            this.StatustextBoxAddAssi.Size = new System.Drawing.Size(136, 22);
            this.StatustextBoxAddAssi.TabIndex = 143;
            // 
            // ObtainedMarkstextBoxAddAssi
            // 
            this.ObtainedMarkstextBoxAddAssi.ForeColor = System.Drawing.Color.Green;
            this.ObtainedMarkstextBoxAddAssi.Location = new System.Drawing.Point(590, 233);
            this.ObtainedMarkstextBoxAddAssi.Margin = new System.Windows.Forms.Padding(4);
            this.ObtainedMarkstextBoxAddAssi.Name = "ObtainedMarkstextBoxAddAssi";
            this.ObtainedMarkstextBoxAddAssi.Size = new System.Drawing.Size(50, 22);
            this.ObtainedMarkstextBoxAddAssi.TabIndex = 140;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.Color.Green;
            this.label86.Location = new System.Drawing.Point(396, 138);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(167, 29);
            this.label86.TabIndex = 137;
            this.label86.Text = "Assignment ID";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.ForeColor = System.Drawing.Color.Green;
            this.label87.Location = new System.Drawing.Point(382, 233);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(183, 29);
            this.label87.TabIndex = 136;
            this.label87.Text = "Obtained Marks";
            // 
            // SubmitbuttonAddAssi
            // 
            this.SubmitbuttonAddAssi.BackColor = System.Drawing.Color.Green;
            this.SubmitbuttonAddAssi.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitbuttonAddAssi.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.SubmitbuttonAddAssi.Location = new System.Drawing.Point(942, 522);
            this.SubmitbuttonAddAssi.Margin = new System.Windows.Forms.Padding(4);
            this.SubmitbuttonAddAssi.Name = "SubmitbuttonAddAssi";
            this.SubmitbuttonAddAssi.Size = new System.Drawing.Size(128, 50);
            this.SubmitbuttonAddAssi.TabIndex = 133;
            this.SubmitbuttonAddAssi.Text = "Submit";
            this.SubmitbuttonAddAssi.UseVisualStyleBackColor = false;
            this.SubmitbuttonAddAssi.Click += new System.EventHandler(this.SubmitbuttonAddAssi_Click);
            // 
            // BackbuttonAddAssi
            // 
            this.BackbuttonAddAssi.BackColor = System.Drawing.Color.Green;
            this.BackbuttonAddAssi.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackbuttonAddAssi.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackbuttonAddAssi.Location = new System.Drawing.Point(85, 522);
            this.BackbuttonAddAssi.Margin = new System.Windows.Forms.Padding(4);
            this.BackbuttonAddAssi.Name = "BackbuttonAddAssi";
            this.BackbuttonAddAssi.Size = new System.Drawing.Size(107, 50);
            this.BackbuttonAddAssi.TabIndex = 134;
            this.BackbuttonAddAssi.Text = "Back";
            this.BackbuttonAddAssi.UseVisualStyleBackColor = false;
            this.BackbuttonAddAssi.Click += new System.EventHandler(this.BackbuttonAddAssi_Click);
            // 
            // label89
            // 
            this.label89.BackColor = System.Drawing.Color.Green;
            this.label89.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label89.Location = new System.Drawing.Point(-8, 0);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label89.Size = new System.Drawing.Size(1176, 42);
            this.label89.TabIndex = 132;
            this.label89.Text = "          ADD ASSIGNMENT DETAILS";
            // 
            // tabPage13
            // 
            this.tabPage13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage13.Controls.Add(this.dataGridViewAttemptsExam);
            this.tabPage13.Controls.Add(this.ExamIDtextBoxAddExam);
            this.tabPage13.Controls.Add(this.label93);
            this.tabPage13.Controls.Add(this.StatustextBoxAddExam);
            this.tabPage13.Controls.Add(this.ObtainedMarkstextBoxAddExam);
            this.tabPage13.Controls.Add(this.label96);
            this.tabPage13.Controls.Add(this.label97);
            this.tabPage13.Controls.Add(this.SubmitbuttonAddExam);
            this.tabPage13.Controls.Add(this.BacktextBoxAddExam);
            this.tabPage13.Controls.Add(this.label99);
            this.tabPage13.Location = new System.Drawing.Point(4, 25);
            this.tabPage13.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage13.Size = new System.Drawing.Size(1165, 617);
            this.tabPage13.TabIndex = 12;
            this.tabPage13.Text = "Add Exam Details";
            // 
            // dataGridViewAttemptsExam
            // 
            this.dataGridViewAttemptsExam.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dataGridViewAttemptsExam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAttemptsExam.Location = new System.Drawing.Point(35, 310);
            this.dataGridViewAttemptsExam.Name = "dataGridViewAttemptsExam";
            this.dataGridViewAttemptsExam.RowHeadersWidth = 51;
            this.dataGridViewAttemptsExam.RowTemplate.Height = 24;
            this.dataGridViewAttemptsExam.Size = new System.Drawing.Size(1061, 150);
            this.dataGridViewAttemptsExam.TabIndex = 150;
            // 
            // ExamIDtextBoxAddExam
            // 
            this.ExamIDtextBoxAddExam.ForeColor = System.Drawing.Color.Green;
            this.ExamIDtextBoxAddExam.Location = new System.Drawing.Point(594, 132);
            this.ExamIDtextBoxAddExam.Margin = new System.Windows.Forms.Padding(4);
            this.ExamIDtextBoxAddExam.Name = "ExamIDtextBoxAddExam";
            this.ExamIDtextBoxAddExam.Size = new System.Drawing.Size(95, 22);
            this.ExamIDtextBoxAddExam.TabIndex = 149;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.ForeColor = System.Drawing.Color.Green;
            this.label93.Location = new System.Drawing.Point(483, 170);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(92, 31);
            this.label93.TabIndex = 145;
            this.label93.Text = "Status";
            // 
            // StatustextBoxAddExam
            // 
            this.StatustextBoxAddExam.ForeColor = System.Drawing.Color.Green;
            this.StatustextBoxAddExam.Location = new System.Drawing.Point(594, 178);
            this.StatustextBoxAddExam.Margin = new System.Windows.Forms.Padding(4);
            this.StatustextBoxAddExam.Name = "StatustextBoxAddExam";
            this.StatustextBoxAddExam.Size = new System.Drawing.Size(136, 22);
            this.StatustextBoxAddExam.TabIndex = 143;
            // 
            // ObtainedMarkstextBoxAddExam
            // 
            this.ObtainedMarkstextBoxAddExam.ForeColor = System.Drawing.Color.Green;
            this.ObtainedMarkstextBoxAddExam.Location = new System.Drawing.Point(594, 222);
            this.ObtainedMarkstextBoxAddExam.Margin = new System.Windows.Forms.Padding(4);
            this.ObtainedMarkstextBoxAddExam.Name = "ObtainedMarkstextBoxAddExam";
            this.ObtainedMarkstextBoxAddExam.Size = new System.Drawing.Size(50, 22);
            this.ObtainedMarkstextBoxAddExam.TabIndex = 140;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.ForeColor = System.Drawing.Color.Green;
            this.label96.Location = new System.Drawing.Point(466, 126);
            this.label96.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(102, 29);
            this.label96.TabIndex = 137;
            this.label96.Text = "Exam ID";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.ForeColor = System.Drawing.Color.Green;
            this.label97.Location = new System.Drawing.Point(382, 217);
            this.label97.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(183, 29);
            this.label97.TabIndex = 136;
            this.label97.Text = "Obtained Marks";
            // 
            // SubmitbuttonAddExam
            // 
            this.SubmitbuttonAddExam.BackColor = System.Drawing.Color.Green;
            this.SubmitbuttonAddExam.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitbuttonAddExam.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.SubmitbuttonAddExam.Location = new System.Drawing.Point(968, 523);
            this.SubmitbuttonAddExam.Margin = new System.Windows.Forms.Padding(4);
            this.SubmitbuttonAddExam.Name = "SubmitbuttonAddExam";
            this.SubmitbuttonAddExam.Size = new System.Drawing.Size(128, 50);
            this.SubmitbuttonAddExam.TabIndex = 133;
            this.SubmitbuttonAddExam.Text = "Submit";
            this.SubmitbuttonAddExam.UseVisualStyleBackColor = false;
            this.SubmitbuttonAddExam.Click += new System.EventHandler(this.SubmitbuttonAddExam_Click);
            // 
            // BacktextBoxAddExam
            // 
            this.BacktextBoxAddExam.BackColor = System.Drawing.Color.Green;
            this.BacktextBoxAddExam.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BacktextBoxAddExam.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BacktextBoxAddExam.Location = new System.Drawing.Point(83, 523);
            this.BacktextBoxAddExam.Margin = new System.Windows.Forms.Padding(4);
            this.BacktextBoxAddExam.Name = "BacktextBoxAddExam";
            this.BacktextBoxAddExam.Size = new System.Drawing.Size(120, 50);
            this.BacktextBoxAddExam.TabIndex = 134;
            this.BacktextBoxAddExam.Text = "Back";
            this.BacktextBoxAddExam.UseVisualStyleBackColor = false;
            this.BacktextBoxAddExam.Click += new System.EventHandler(this.BacktextBoxAddExam_Click);
            // 
            // label99
            // 
            this.label99.BackColor = System.Drawing.Color.Green;
            this.label99.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label99.Location = new System.Drawing.Point(-8, 0);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label99.Size = new System.Drawing.Size(1176, 42);
            this.label99.TabIndex = 132;
            this.label99.Text = "                     ADD EXAM DETAILS ";
            // 
            // tabPage15
            // 
            this.tabPage15.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage15.Controls.Add(this.Job);
            this.tabPage15.Controls.Add(this.Project);
            this.tabPage15.Controls.Add(this.Internships);
            this.tabPage15.Controls.Add(this.JobtableLayoutPanel);
            this.tabPage15.Controls.Add(this.ProjecttableLayoutPanel);
            this.tabPage15.Controls.Add(this.label216);
            this.tabPage15.Controls.Add(this.InternshiptableLayoutPanel);
            this.tabPage15.Controls.Add(this.SearchbuttonSearchStudentCareer);
            this.tabPage15.Controls.Add(this.BackbuttonSearchStudentCareer);
            this.tabPage15.Location = new System.Drawing.Point(4, 25);
            this.tabPage15.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage15.Size = new System.Drawing.Size(1165, 617);
            this.tabPage15.TabIndex = 14;
            this.tabPage15.Text = "Student Career";
            // 
            // Job
            // 
            this.Job.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Job.Location = new System.Drawing.Point(154, 404);
            this.Job.Name = "Job";
            this.Job.RowHeadersWidth = 51;
            this.Job.RowTemplate.Height = 24;
            this.Job.Size = new System.Drawing.Size(847, 98);
            this.Job.TabIndex = 80;
            // 
            // Project
            // 
            this.Project.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Project.Location = new System.Drawing.Point(154, 253);
            this.Project.Name = "Project";
            this.Project.RowHeadersWidth = 51;
            this.Project.RowTemplate.Height = 24;
            this.Project.Size = new System.Drawing.Size(847, 106);
            this.Project.TabIndex = 79;
            // 
            // Internships
            // 
            this.Internships.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Internships.Location = new System.Drawing.Point(154, 104);
            this.Internships.Name = "Internships";
            this.Internships.RowHeadersWidth = 51;
            this.Internships.RowTemplate.Height = 24;
            this.Internships.Size = new System.Drawing.Size(847, 104);
            this.Internships.TabIndex = 78;
            // 
            // JobtableLayoutPanel
            // 
            this.JobtableLayoutPanel.BackColor = System.Drawing.Color.Firebrick;
            this.JobtableLayoutPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.JobtableLayoutPanel.ColumnCount = 5;
            this.JobtableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.625F));
            this.JobtableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.375F));
            this.JobtableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.JobtableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 276F));
            this.JobtableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168F));
            this.JobtableLayoutPanel.Controls.Add(this.label150, 3, 0);
            this.JobtableLayoutPanel.Controls.Add(this.label195, 0, 0);
            this.JobtableLayoutPanel.Controls.Add(this.label153, 4, 0);
            this.JobtableLayoutPanel.Controls.Add(this.label155, 1, 0);
            this.JobtableLayoutPanel.Controls.Add(this.label158, 2, 0);
            this.JobtableLayoutPanel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JobtableLayoutPanel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.JobtableLayoutPanel.Location = new System.Drawing.Point(154, 366);
            this.JobtableLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.JobtableLayoutPanel.Name = "JobtableLayoutPanel";
            this.JobtableLayoutPanel.RowCount = 1;
            this.JobtableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 61.29032F));
            this.JobtableLayoutPanel.Size = new System.Drawing.Size(847, 44);
            this.JobtableLayoutPanel.TabIndex = 77;
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label150.Location = new System.Drawing.Point(400, 3);
            this.label150.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(184, 26);
            this.label150.TabIndex = 3;
            this.label150.Text = "              Company";
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label195.Location = new System.Drawing.Point(7, 3);
            this.label195.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(54, 26);
            this.label195.TabIndex = 2;
            this.label195.Text = "Jobs";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label153.Location = new System.Drawing.Point(679, 3);
            this.label153.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(117, 23);
            this.label153.TabIndex = 4;
            this.label153.Text = "Time Period\r\n";
            // 
            // label155
            // 
            this.label155.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label155.Location = new System.Drawing.Point(199, 3);
            this.label155.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(37, 32);
            this.label155.TabIndex = 0;
            this.label155.Text = "ID";
            this.label155.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label158.Location = new System.Drawing.Point(301, 3);
            this.label158.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(83, 26);
            this.label158.TabIndex = 2;
            this.label158.Text = "  Status";
            // 
            // ProjecttableLayoutPanel
            // 
            this.ProjecttableLayoutPanel.BackColor = System.Drawing.Color.Firebrick;
            this.ProjecttableLayoutPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.ProjecttableLayoutPanel.ColumnCount = 5;
            this.ProjecttableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.625F));
            this.ProjecttableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.375F));
            this.ProjecttableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.ProjecttableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 276F));
            this.ProjecttableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168F));
            this.ProjecttableLayoutPanel.Controls.Add(this.label141, 3, 0);
            this.ProjecttableLayoutPanel.Controls.Add(this.label208, 0, 0);
            this.ProjecttableLayoutPanel.Controls.Add(this.label144, 4, 0);
            this.ProjecttableLayoutPanel.Controls.Add(this.label147, 1, 0);
            this.ProjecttableLayoutPanel.Controls.Add(this.label149, 2, 0);
            this.ProjecttableLayoutPanel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProjecttableLayoutPanel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ProjecttableLayoutPanel.Location = new System.Drawing.Point(154, 215);
            this.ProjecttableLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.ProjecttableLayoutPanel.Name = "ProjecttableLayoutPanel";
            this.ProjecttableLayoutPanel.RowCount = 1;
            this.ProjecttableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 61.29032F));
            this.ProjecttableLayoutPanel.Size = new System.Drawing.Size(847, 39);
            this.ProjecttableLayoutPanel.TabIndex = 76;
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.Location = new System.Drawing.Point(400, 3);
            this.label141.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(184, 26);
            this.label141.TabIndex = 3;
            this.label141.Text = "              Company";
            // 
            // label208
            // 
            this.label208.AutoSize = true;
            this.label208.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label208.Location = new System.Drawing.Point(7, 3);
            this.label208.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(88, 26);
            this.label208.TabIndex = 2;
            this.label208.Text = "Projects";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label144.Location = new System.Drawing.Point(679, 3);
            this.label144.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(117, 23);
            this.label144.TabIndex = 4;
            this.label144.Text = "Time Period\r\n";
            // 
            // label147
            // 
            this.label147.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label147.Location = new System.Drawing.Point(199, 3);
            this.label147.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(37, 32);
            this.label147.TabIndex = 0;
            this.label147.Text = "ID";
            this.label147.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label149.Location = new System.Drawing.Point(301, 3);
            this.label149.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(83, 26);
            this.label149.TabIndex = 2;
            this.label149.Text = "  Status";
            // 
            // label216
            // 
            this.label216.BackColor = System.Drawing.Color.Firebrick;
            this.label216.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label216.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label216.Location = new System.Drawing.Point(-8, 0);
            this.label216.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label216.Name = "label216";
            this.label216.Padding = new System.Windows.Forms.Padding(220, 0, 0, 0);
            this.label216.Size = new System.Drawing.Size(1176, 42);
            this.label216.TabIndex = 74;
            this.label216.Text = "            STUDENT CAREER DETAILS";
            // 
            // InternshiptableLayoutPanel
            // 
            this.InternshiptableLayoutPanel.BackColor = System.Drawing.Color.Firebrick;
            this.InternshiptableLayoutPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.InternshiptableLayoutPanel.ColumnCount = 5;
            this.InternshiptableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.5098F));
            this.InternshiptableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.4902F));
            this.InternshiptableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.InternshiptableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 276F));
            this.InternshiptableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168F));
            this.InternshiptableLayoutPanel.Controls.Add(this.label221, 3, 0);
            this.InternshiptableLayoutPanel.Controls.Add(this.label222, 0, 0);
            this.InternshiptableLayoutPanel.Controls.Add(this.label224, 4, 0);
            this.InternshiptableLayoutPanel.Controls.Add(this.label227, 1, 0);
            this.InternshiptableLayoutPanel.Controls.Add(this.label229, 2, 0);
            this.InternshiptableLayoutPanel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InternshiptableLayoutPanel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.InternshiptableLayoutPanel.Location = new System.Drawing.Point(154, 66);
            this.InternshiptableLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.InternshiptableLayoutPanel.Name = "InternshiptableLayoutPanel";
            this.InternshiptableLayoutPanel.RowCount = 1;
            this.InternshiptableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 61.29032F));
            this.InternshiptableLayoutPanel.Size = new System.Drawing.Size(847, 38);
            this.InternshiptableLayoutPanel.TabIndex = 71;
            // 
            // label221
            // 
            this.label221.AutoSize = true;
            this.label221.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label221.Location = new System.Drawing.Point(400, 3);
            this.label221.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label221.Name = "label221";
            this.label221.Size = new System.Drawing.Size(184, 26);
            this.label221.TabIndex = 3;
            this.label221.Text = "              Company";
            // 
            // label222
            // 
            this.label222.AutoSize = true;
            this.label222.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label222.Location = new System.Drawing.Point(7, 3);
            this.label222.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(123, 26);
            this.label222.TabIndex = 2;
            this.label222.Text = " Internships";
            // 
            // label224
            // 
            this.label224.AutoSize = true;
            this.label224.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label224.Location = new System.Drawing.Point(679, 3);
            this.label224.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label224.Name = "label224";
            this.label224.Size = new System.Drawing.Size(117, 23);
            this.label224.TabIndex = 4;
            this.label224.Text = "Time Period\r\n";
            // 
            // label227
            // 
            this.label227.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label227.Location = new System.Drawing.Point(225, 3);
            this.label227.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label227.Name = "label227";
            this.label227.Size = new System.Drawing.Size(37, 32);
            this.label227.TabIndex = 0;
            this.label227.Text = "ID";
            this.label227.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label229
            // 
            this.label229.AutoSize = true;
            this.label229.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label229.Location = new System.Drawing.Point(301, 3);
            this.label229.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label229.Name = "label229";
            this.label229.Size = new System.Drawing.Size(83, 26);
            this.label229.TabIndex = 2;
            this.label229.Text = "  Status";
            // 
            // SearchbuttonSearchStudentCareer
            // 
            this.SearchbuttonSearchStudentCareer.BackColor = System.Drawing.Color.Firebrick;
            this.SearchbuttonSearchStudentCareer.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchbuttonSearchStudentCareer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SearchbuttonSearchStudentCareer.Location = new System.Drawing.Point(499, 509);
            this.SearchbuttonSearchStudentCareer.Margin = new System.Windows.Forms.Padding(4);
            this.SearchbuttonSearchStudentCareer.Name = "SearchbuttonSearchStudentCareer";
            this.SearchbuttonSearchStudentCareer.Size = new System.Drawing.Size(162, 46);
            this.SearchbuttonSearchStudentCareer.TabIndex = 70;
            this.SearchbuttonSearchStudentCareer.Text = "View All";
            this.SearchbuttonSearchStudentCareer.UseVisualStyleBackColor = false;
            this.SearchbuttonSearchStudentCareer.Click += new System.EventHandler(this.SearchbuttonSearchStudentCareer_Click);
            // 
            // BackbuttonSearchStudentCareer
            // 
            this.BackbuttonSearchStudentCareer.BackColor = System.Drawing.Color.Firebrick;
            this.BackbuttonSearchStudentCareer.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackbuttonSearchStudentCareer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackbuttonSearchStudentCareer.Location = new System.Drawing.Point(515, 563);
            this.BackbuttonSearchStudentCareer.Margin = new System.Windows.Forms.Padding(4);
            this.BackbuttonSearchStudentCareer.Name = "BackbuttonSearchStudentCareer";
            this.BackbuttonSearchStudentCareer.Size = new System.Drawing.Size(121, 43);
            this.BackbuttonSearchStudentCareer.TabIndex = 69;
            this.BackbuttonSearchStudentCareer.Text = "Back";
            this.BackbuttonSearchStudentCareer.UseVisualStyleBackColor = false;
            this.BackbuttonSearchStudentCareer.Click += new System.EventHandler(this.BackbuttonSearchStudentCareer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1172, 638);
            this.Controls.Add(this.AddMarks);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "STUDENT PLANNER";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.AddMarks.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_StudentCourses)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllCourses)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_StudentHabbit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllHabts)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_StudentActivity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllActivities)).EndInit();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Result)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridallcourses)).EndInit();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewQuizzes)).EndInit();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAttempAssignment)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAttemptsExam)).EndInit();
            this.tabPage15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Job)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Project)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Internships)).EndInit();
            this.JobtableLayoutPanel.ResumeLayout(false);
            this.JobtableLayoutPanel.PerformLayout();
            this.ProjecttableLayoutPanel.ResumeLayout(false);
            this.ProjecttableLayoutPanel.PerformLayout();
            this.InternshiptableLayoutPanel.ResumeLayout(false);
            this.InternshiptableLayoutPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl AddMarks;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label LabelDateTime;
        private System.Windows.Forms.Button ButtonCreateNewUser;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TextBox textBoxPersonalActivityTime;
        private System.Windows.Forms.TextBox textBoxPersonalActivityID;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBoxActivityName;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button MainMenuButtonPersonalActivity;
        private System.Windows.Forms.Button SubmitButtonPersonalActivity;
        private System.Windows.Forms.TextBox textBoxHabitDuration;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button MainMenuButtonHabit;
        private System.Windows.Forms.TextBox textBoxHabitID;
        private System.Windows.Forms.TextBox textBoxHabitName;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBoxHabitTimeRemaining;
        private System.Windows.Forms.TextBox textBoxHabitTimeAllocated;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBoxPlannerID;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button MainMenuButtonCareerPlanner;
        private System.Windows.Forms.Button submitButtonCareerPlanner;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBoxInternshipTimePeriod;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBoxInternshipCompany;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBoxInternshipID;
        private System.Windows.Forms.CheckBox checkBoxJobApplication;
        private System.Windows.Forms.CheckBox checkBoxProject;
        private System.Windows.Forms.CheckBox checkBoxInternship;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBoxJobTimePeriod;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBoxProjectCompany;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBoxJobID;
        private System.Windows.Forms.TextBox textBoxProjectTimePeriod;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBoxJobCompany;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBoxProjectID;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Button ButtonBackLogin;
        private System.Windows.Forms.Button SubmitButtonLogin;
        private System.Windows.Forms.TextBox TextboxLoginCMSID;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox TextBoxAddStuCMSID;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button BackButtonAddStu;
        private System.Windows.Forms.Button SubmitButtonAddStu;
        private System.Windows.Forms.TextBox TextBoxAddStuFirstName;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox TextBoxAddStuBirthDate;
        private System.Windows.Forms.TextBox TextBoxAddStuLastName;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox TextBoxAddStuDepartment;
        private System.Windows.Forms.TextBox TextBoxAddStuCity;
        private System.Windows.Forms.TextBox TextBoxAddStuNoOfCourses;
        private System.Windows.Forms.TextBox TextBoxAddStuSemNo;
        private System.Windows.Forms.Label labelDT;
        private System.Windows.Forms.Button buttonAddCourse;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Button buttonGrades;
        private System.Windows.Forms.Button buttonAddCareer;
        private System.Windows.Forms.Button buttonAddHabit;
        private System.Windows.Forms.Button buttonAddActivity;
        private System.Windows.Forms.Button buttonLogOut;
        private System.Windows.Forms.Button MAinMenuButtonAddCourse;
        private System.Windows.Forms.Button MainMenuButtonGradesGPA;
        private System.Windows.Forms.Button SearchButtonGradesGPA;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.Button ButtonLoginOldUser;
        private System.Windows.Forms.TextBox CourseIDtextBoxAddcourse;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CourseNametextBoxAddcourse;
        private System.Windows.Forms.TextBox CreditHourstextBoxAddcourse;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button submitButtonAddCourse;
        private System.Windows.Forms.TextBox QuizIDtextBoxQuiz;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox StatustextBoxQuiz;
        private System.Windows.Forms.TextBox ObtainedMarkstextBoxQuiz;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button SubmitbuttonAddQuiz;
        private System.Windows.Forms.Button BackbuttonAddQuiz;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TextBox AssiIDtextBoxAddAssi;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox StatustextBoxAddAssi;
        private System.Windows.Forms.TextBox ObtainedMarkstextBoxAddAssi;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Button SubmitbuttonAddAssi;
        private System.Windows.Forms.Button BackbuttonAddAssi;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TextBox ExamIDtextBoxAddExam;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox StatustextBoxAddExam;
        private System.Windows.Forms.TextBox ObtainedMarkstextBoxAddExam;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Button SubmitbuttonAddExam;
        private System.Windows.Forms.Button BacktextBoxAddExam;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Button AddQuizMarksButton;
        private System.Windows.Forms.Button AddAssiMarksButton;
        private System.Windows.Forms.Button AddExamMarks;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TableLayoutPanel ProjecttableLayoutPanel;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.Label label216;
        private System.Windows.Forms.TableLayoutPanel InternshiptableLayoutPanel;
        private System.Windows.Forms.Label label221;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.Label label224;
        private System.Windows.Forms.Label label227;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.Button SearchbuttonSearchStudentCareer;
        private System.Windows.Forms.Button BackbuttonSearchStudentCareer;
        private System.Windows.Forms.TableLayoutPanel JobtableLayoutPanel;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Button CalculateGPAbutton;
        private System.Windows.Forms.TextBox sex;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox InstructorEmailtextBoxAddcourse;
        private System.Windows.Forms.TextBox InstructorNametextBoxAddcourse;
        private System.Windows.Forms.TextBox InstructorMobileNotextBoxAddcourse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.DataGridView dataGridViewAllCourses;
        private System.Windows.Forms.TextBox status;
        private System.Windows.Forms.DataGridView dataGridViewQuizzes;
        private System.Windows.Forms.DataGridView dataGridViewAttempAssignment;
        private System.Windows.Forms.DataGridView dataGridViewAttemptsExam;
        private System.Windows.Forms.DataGridView dataGridViewAllHabts;
        private System.Windows.Forms.DataGridView dataGridViewAllActivities;
        private System.Windows.Forms.DataGridView dataGridView_StudentHabbit;
        private System.Windows.Forms.DataGridView dataGridView_StudentActivity;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView_StudentCourses;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox student_course;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox Deadline;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox title;
        private System.Windows.Forms.DataGridView Internships;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView gridallcourses;
        private System.Windows.Forms.DataGridView Result;
        private System.Windows.Forms.DataGridView Job;
        private System.Windows.Forms.DataGridView Project;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Button SubmitButtonHabit;
    }
}

